#!/usr/bin/env bash
# Smoke test for a running AURORA stack (Docker Compose or local dev servers).
# Exits non-zero on the first failed check. Reports only what was actually observed.
#
# Usage: ./infra/scripts/smoke.sh [API_URL] [WEB_URL]
set -euo pipefail

API_URL="${1:-${API_URL:-http://localhost:8000}}"
WEB_URL="${2:-${WEB_URL:-http://localhost:3000}}"

fail() { echo "FAIL: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

http_status() {
  curl --silent --show-error --max-time 10 --output /dev/null --write-out '%{http_code}' "$1"
}

status="$(http_status "${API_URL}/api/v1/health")" || fail "API liveness unreachable at ${API_URL}"
[ "${status}" = "200" ] || fail "API liveness returned HTTP ${status} (expected 200)"
pass "API liveness ${API_URL}/api/v1/health -> 200"

ready_body="$(curl --silent --show-error --max-time 10 "${API_URL}/api/v1/health/ready")" \
  || fail "API readiness unreachable"
ready_status="$(http_status "${API_URL}/api/v1/health/ready")"
[ "${ready_status}" = "200" ] || fail "API readiness returned HTTP ${ready_status}: ${ready_body}"
echo "${ready_body}" | grep -q '"database":"ok"' || fail "database check is not ok: ${ready_body}"
pass "API readiness -> 200, database ok"

status="$(http_status "${WEB_URL}/")" || fail "Web unreachable at ${WEB_URL}"
[ "${status}" = "200" ] || fail "Web returned HTTP ${status} (expected 200)"
pass "Web ${WEB_URL}/ -> 200"

echo "All smoke checks passed."
