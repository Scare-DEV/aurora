# shared-contracts

Reserved for API contracts shared between `apps/web` and `services/api`
(for example a generated OpenAPI schema and TypeScript types derived from it).

**Status (Milestone 1):** intentionally empty. The FastAPI OpenAPI document is the
source of truth, and `apps/web/src/lib/api/schemas.ts` holds hand-written Zod
schemas for the few endpoints that exist so far. Contract generation and a
contract test are scheduled with the endpoint-heavy milestones (2 and 6).
