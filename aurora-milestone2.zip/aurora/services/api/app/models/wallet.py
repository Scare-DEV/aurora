"""Demo wallet. Balances are integer credit units (no floating point)."""

from __future__ import annotations

import uuid

from sqlalchemy import BigInteger, CheckConstraint, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.models._mixins import TimestampMixin, UUIDPrimaryKeyMixin

DEMO_CURRENCY = "DEMO"


class Wallet(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "wallets"

    # RESTRICT: financial history must never vanish with a user row.
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="RESTRICT"), nullable=False, unique=True
    )
    currency_code: Mapped[str] = mapped_column(
        String(8), nullable=False, default=DEMO_CURRENCY, server_default=DEMO_CURRENCY
    )
    balance_units: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0, server_default="0"
    )
    version: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0, server_default="0")

    __table_args__ = (
        CheckConstraint("balance_units >= 0", name="balance_nonnegative"),
        CheckConstraint("currency_code = 'DEMO'", name="currency_is_demo"),
    )
