"""Import every model so that ``Base.metadata`` is complete (Alembic relies on this)."""

from app.models.achievement import Achievement, UserAchievement
from app.models.app_setting import AppSetting
from app.models.audit_log import AuditLog
from app.models.game import Favorite, Game
from app.models.game_round import GameRound, RoundStatus
from app.models.user import AuthSession, User, UserRole, UserStatus
from app.models.wallet import Wallet
from app.models.wallet_ledger import LedgerEntryType, WalletLedgerEntry

__all__ = [
    "Achievement",
    "AppSetting",
    "AuditLog",
    "AuthSession",
    "Favorite",
    "Game",
    "GameRound",
    "LedgerEntryType",
    "RoundStatus",
    "User",
    "UserAchievement",
    "UserRole",
    "UserStatus",
    "Wallet",
    "WalletLedgerEntry",
]
