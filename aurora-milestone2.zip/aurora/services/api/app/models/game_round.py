"""Game rounds and their explicit state machine."""

from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import BigInteger, CheckConstraint, DateTime, ForeignKey, Index, String, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.models._mixins import CreatedAtMixin, UUIDPrimaryKeyMixin


class RoundStatus(enum.StrEnum):
    CREATED = "CREATED"
    # Multi-step games (Mines) sit here between the first action and settlement.
    IN_PROGRESS = "IN_PROGRESS"
    SETTLED = "SETTLED"
    CANCELLED = "CANCELLED"


# Explicit, validated transitions. Anything not listed is rejected by the service layer.
ALLOWED_TRANSITIONS: dict[RoundStatus, frozenset[RoundStatus]] = {
    RoundStatus.CREATED: frozenset(
        {RoundStatus.IN_PROGRESS, RoundStatus.SETTLED, RoundStatus.CANCELLED}
    ),
    RoundStatus.IN_PROGRESS: frozenset({RoundStatus.SETTLED, RoundStatus.CANCELLED}),
    RoundStatus.SETTLED: frozenset(),
    RoundStatus.CANCELLED: frozenset(),
}


def can_transition(current: RoundStatus, target: RoundStatus) -> bool:
    return target in ALLOWED_TRANSITIONS[current]


class GameRound(UUIDPrimaryKeyMixin, CreatedAtMixin, Base):
    __tablename__ = "game_rounds"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    game_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("games.id", ondelete="RESTRICT"), nullable=False
    )
    status: Mapped[str] = mapped_column(
        String(16), nullable=False, default=RoundStatus.CREATED.value, server_default="CREATED"
    )
    stake_units: Mapped[int] = mapped_column(BigInteger, nullable=False)
    payout_units: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0, server_default="0"
    )
    net_result_units: Mapped[int] = mapped_column(
        BigInteger, nullable=False, default=0, server_default="0"
    )
    input_snapshot: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    result_snapshot: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)
    # Secret server-side state (e.g. Mines positions). NEVER serialized into API responses
    # while the round is unsettled; response schemas must not include this column.
    private_state: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)
    idempotency_key: Mapped[str] = mapped_column(String(128), nullable=False)
    settled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        CheckConstraint(
            "status IN ('CREATED', 'IN_PROGRESS', 'SETTLED', 'CANCELLED')", name="status_valid"
        ),
        CheckConstraint("stake_units > 0", name="stake_positive"),
        CheckConstraint("payout_units >= 0", name="payout_nonnegative"),
        CheckConstraint(
            "status <> 'SETTLED' OR settled_at IS NOT NULL", name="settled_has_timestamp"
        ),
        CheckConstraint(
            "status <> 'SETTLED' OR net_result_units = payout_units - stake_units",
            name="settled_net_consistent",
        ),
        # Same user + same key = same round: the retry must not create a second one.
        Index("uq_game_rounds_user_idempotency", "user_id", "idempotency_key", unique=True),
        Index("ix_game_rounds_user_created", "user_id", text("created_at DESC")),
        Index("ix_game_rounds_game_status", "game_id", "status"),
    )
