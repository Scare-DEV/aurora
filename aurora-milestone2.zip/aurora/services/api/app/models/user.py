"""Users and authentication sessions."""

from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.models._mixins import CreatedAtMixin, TimestampMixin, UUIDPrimaryKeyMixin


class UserRole(enum.StrEnum):
    PLAYER = "player"
    ADMIN = "admin"


class UserStatus(enum.StrEnum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    DELETED = "deleted"


def _in_list(column: str, values: type[enum.StrEnum]) -> str:
    return f"{column} IN ({', '.join(repr(v.value) for v in values)})"


class User(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "users"
    # Fetch server-generated defaults (created_at, ...) via RETURNING so async code never
    # triggers an implicit lazy load on a freshly inserted row.
    __mapper_args__ = {"eager_defaults": True}  # noqa: RUF012

    # Stored normalized (lower-cased, trimmed); the CHECK enforces it for every writer.
    email: Mapped[str] = mapped_column(String(320), nullable=False, unique=True)
    # Nullable for future external authentication; never a plaintext password.
    password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    username: Mapped[str] = mapped_column(String(32), nullable=False)
    role: Mapped[str] = mapped_column(
        String(16), nullable=False, default=UserRole.PLAYER.value, server_default="player"
    )
    status: Mapped[str] = mapped_column(
        String(16), nullable=False, default=UserStatus.ACTIVE.value, server_default="active"
    )
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        CheckConstraint("email = lower(btrim(email))", name="email_normalized"),
        CheckConstraint(_in_list("role", UserRole), name="role_valid"),
        CheckConstraint(_in_list("status", UserStatus), name="status_valid"),
    )


# Usernames are unique case-insensitively ("Ada" and "ada" collide). Defined after the
# class so the expression can reference the mapped column.
Index("uq_users_username_lower", func.lower(User.username), unique=True)


class AuthSession(UUIDPrimaryKeyMixin, CreatedAtMixin, Base):
    """Server-side session. Only a SHA-256 hash of the cookie token is stored."""

    __tablename__ = "sessions"
    __mapper_args__ = {"eager_defaults": True}  # noqa: RUF012

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    token_hash: Mapped[str] = mapped_column(String(64), nullable=False, unique=True)
    last_seen_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(256), nullable=True)

    __table_args__ = (
        Index("ix_sessions_user_id", "user_id"),
        Index("ix_sessions_expires_at", "expires_at"),
    )
