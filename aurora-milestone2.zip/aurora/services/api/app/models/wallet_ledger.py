"""Immutable wallet ledger. Rows are only ever inserted (enforced by a DB trigger)."""

from __future__ import annotations

import enum
import uuid
from typing import Any

from sqlalchemy import BigInteger, CheckConstraint, ForeignKey, Index, String, text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.models._mixins import CreatedAtMixin, UUIDPrimaryKeyMixin


class LedgerEntryType(enum.StrEnum):
    INITIAL_GRANT = "INITIAL_GRANT"
    DAILY_CLAIM = "DAILY_CLAIM"
    STAKE_DEBIT = "STAKE_DEBIT"
    PAYOUT_CREDIT = "PAYOUT_CREDIT"
    ADMIN_ADJUSTMENT = "ADMIN_ADJUSTMENT"
    # Corrections are compensating entries, never edits of history.
    REVERSAL = "REVERSAL"


class WalletLedgerEntry(UUIDPrimaryKeyMixin, CreatedAtMixin, Base):
    __tablename__ = "wallet_ledger"

    wallet_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("wallets.id", ondelete="RESTRICT"), nullable=False
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    round_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("game_rounds.id", ondelete="RESTRICT"), nullable=True
    )
    entry_type: Mapped[str] = mapped_column(String(24), nullable=False)
    amount_units: Mapped[int] = mapped_column(BigInteger, nullable=False)
    balance_after_units: Mapped[int] = mapped_column(BigInteger, nullable=False)
    # NULL for entries without a natural unique reference; UNIQUE ignores NULLs in PostgreSQL.
    reference_key: Mapped[str | None] = mapped_column(String(160), nullable=True, unique=True)
    # Attribute is `meta` because `metadata` is reserved by SQLAlchemy's declarative base.
    meta: Mapped[dict[str, Any]] = mapped_column(
        "metadata", JSONB, nullable=False, default=dict, server_default=text("'{}'::jsonb")
    )

    __table_args__ = (
        CheckConstraint(
            "entry_type IN ('INITIAL_GRANT', 'DAILY_CLAIM', 'STAKE_DEBIT', 'PAYOUT_CREDIT', "
            "'ADMIN_ADJUSTMENT', 'REVERSAL')",
            name="entry_type_valid",
        ),
        CheckConstraint("amount_units <> 0", name="amount_nonzero"),
        CheckConstraint("balance_after_units >= 0", name="balance_after_nonnegative"),
        CheckConstraint(
            "(entry_type = 'STAKE_DEBIT' AND amount_units < 0) "
            "OR (entry_type IN ('INITIAL_GRANT', 'DAILY_CLAIM', 'PAYOUT_CREDIT') "
            "AND amount_units > 0) "
            "OR entry_type IN ('ADMIN_ADJUSTMENT', 'REVERSAL')",
            name="sign_matches_type",
        ),
        # A round is debited once and paid out at most once.
        Index(
            "uq_wallet_ledger_round_stake",
            "round_id",
            unique=True,
            postgresql_where=text("entry_type = 'STAKE_DEBIT'"),
        ),
        Index(
            "uq_wallet_ledger_round_payout",
            "round_id",
            unique=True,
            postgresql_where=text("entry_type = 'PAYOUT_CREDIT'"),
        ),
        Index("ix_wallet_ledger_wallet_created", "wallet_id", text("created_at DESC")),
    )
