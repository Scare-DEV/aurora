"""Shared FastAPI dependencies."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, Request
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import Settings
from app.core.errors import ForbiddenError, UnauthenticatedError
from app.core.rate_limit import RateLimiter
from app.db.session import get_session
from app.models.user import AuthSession, User, UserRole
from app.services.auth_service import AuthService


def get_app_settings(request: Request) -> Settings:
    settings: Settings = request.app.state.settings
    return settings


def get_optional_redis(request: Request) -> Redis | None:
    client: Redis | None = request.app.state.redis
    return client


SettingsDep = Annotated[Settings, Depends(get_app_settings)]
SessionDep = Annotated[AsyncSession, Depends(get_session)]
RedisDep = Annotated[Redis | None, Depends(get_optional_redis)]


def get_rate_limiter(request: Request) -> RateLimiter:
    limiter: RateLimiter = request.app.state.rate_limiter
    return limiter


RateLimiterDep = Annotated[RateLimiter, Depends(get_rate_limiter)]


def client_ip(request: Request) -> str:
    # request.client is the direct peer. X-Forwarded-For is deliberately NOT trusted here;
    # behind a reverse proxy, configure uvicorn's --proxy-headers/--forwarded-allow-ips.
    return request.client.host if request.client else "unknown"


async def get_auth_service(session: SessionDep, settings: SettingsDep) -> AuthService:
    return AuthService(session, settings)


AuthServiceDep = Annotated[AuthService, Depends(get_auth_service)]


@dataclass(frozen=True)
class AuthContext:
    user: User
    session: AuthSession
    token: str


async def get_auth_context(
    request: Request, settings: SettingsDep, service: AuthServiceDep
) -> AuthContext:
    token = request.cookies.get(settings.session_cookie_name)
    if not token:
        raise UnauthenticatedError()
    resolved = await service.resolve_session(token)
    if resolved is None:
        raise UnauthenticatedError("Your session has expired. Please sign in again.")
    return AuthContext(user=resolved.user, session=resolved.session, token=token)


AuthContextDep = Annotated[AuthContext, Depends(get_auth_context)]


async def get_current_user(ctx: AuthContextDep) -> User:
    return ctx.user


CurrentUser = Annotated[User, Depends(get_current_user)]


async def require_admin(user: CurrentUser) -> User:
    """Server-side role check. Hiding an admin button in the UI is not authorization."""
    if user.role != UserRole.ADMIN.value:
        raise ForbiddenError()
    return user


AdminUser = Annotated[User, Depends(require_admin)]
