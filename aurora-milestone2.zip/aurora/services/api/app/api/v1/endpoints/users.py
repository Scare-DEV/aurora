"""Profile endpoints. A user can only ever read or change their own record."""

from __future__ import annotations

from fastapi import APIRouter

from app.api.dependencies import AuthServiceDep, CurrentUser
from app.schemas.auth import UpdateProfileRequest, UserPublic

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=UserPublic, summary="Get my profile")
async def get_me(user: CurrentUser) -> UserPublic:
    return UserPublic.model_validate(user)


@router.patch("/me", response_model=UserPublic, summary="Update my profile (username only)")
async def update_me(
    payload: UpdateProfileRequest, user: CurrentUser, service: AuthServiceDep
) -> UserPublic:
    # Only whitelisted fields exist on the request schema: role, status, email and balance
    # cannot be changed here (extra fields are rejected with 422).
    if payload.username is not None:
        user = await service.update_username(user, payload.username)
    return UserPublic.model_validate(user)
