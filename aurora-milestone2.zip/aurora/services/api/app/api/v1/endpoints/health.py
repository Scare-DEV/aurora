"""Health endpoints (public, unauthenticated, no sensitive data).

GET /api/v1/health        liveness  -> 200 while the process is running
GET /api/v1/health/ready  readiness -> 200 ok|degraded, 503 when the database is down
"""

from __future__ import annotations

import asyncio
import logging

from fastapi import APIRouter, Response, status
from sqlalchemy import text

from app import __version__
from app.api.dependencies import RedisDep, SessionDep, SettingsDep
from app.schemas.health import ComponentState, HealthResponse, ReadinessResponse

logger = logging.getLogger(__name__)

router = APIRouter(tags=["health"])

_CHECK_TIMEOUT_SECONDS = 3.0


@router.get("/health", response_model=HealthResponse, summary="Liveness probe")
async def liveness(settings: SettingsDep) -> HealthResponse:
    return HealthResponse(status="ok", service=settings.app_name, version=__version__)


@router.get(
    "/health/ready",
    response_model=ReadinessResponse,
    summary="Readiness probe",
    responses={status.HTTP_503_SERVICE_UNAVAILABLE: {"model": ReadinessResponse}},
)
async def readiness(response: Response, session: SessionDep, redis: RedisDep) -> ReadinessResponse:
    checks: dict[str, ComponentState] = {}

    try:
        async with asyncio.timeout(_CHECK_TIMEOUT_SECONDS):
            await session.execute(text("SELECT 1"))
        checks["database"] = "ok"
    except Exception as exc:
        # Report only the exception type: messages may contain connection details.
        logger.warning("database readiness check failed", extra={"error_type": type(exc).__name__})
        checks["database"] = "error"

    if redis is None:
        checks["redis"] = "disabled"
    else:
        try:
            async with asyncio.timeout(_CHECK_TIMEOUT_SECONDS):
                await redis.ping()
            checks["redis"] = "ok"
        except Exception as exc:
            logger.warning("redis readiness check failed", extra={"error_type": type(exc).__name__})
            checks["redis"] = "error"

    if checks["database"] == "error":
        overall = "unavailable"
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    elif checks["redis"] == "error":
        overall = "degraded"
    else:
        overall = "ok"

    return ReadinessResponse(status=overall, version=__version__, checks=checks)
