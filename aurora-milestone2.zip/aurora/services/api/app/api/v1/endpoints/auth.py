"""Authentication endpoints (cookie session; see docs/security.md).

POST /auth/register  201  create account + sign in           409 account_unavailable, 429
POST /auth/login     200  sign in                            401 invalid_credentials, 403, 429
POST /auth/logout    204  revoke the current session (idempotent)
GET  /auth/me        200  current session + CSRF token       401
"""

from __future__ import annotations

from fastapi import APIRouter, Request, Response, status

from app.api.dependencies import (
    AuthContextDep,
    AuthServiceDep,
    RateLimiterDep,
    SettingsDep,
    client_ip,
)
from app.core.config import Settings
from app.core.errors import ForbiddenError, RateLimitedError
from app.core.rate_limit import RateLimiter
from app.core.security import csrf_token_for
from app.schemas.auth import LoginRequest, RegisterRequest, SessionInfo, UserPublic
from app.services.auth_service import IssuedSession

router = APIRouter(prefix="/auth", tags=["auth"])


def _set_session_cookie(response: Response, settings: Settings, issued: IssuedSession) -> None:
    response.set_cookie(
        settings.session_cookie_name,
        issued.token,
        max_age=settings.session_ttl_seconds,
        httponly=True,
        secure=settings.use_secure_cookies,
        samesite=settings.cookie_samesite,
        path="/",
    )


def _session_info(settings: Settings, issued: IssuedSession) -> SessionInfo:
    return SessionInfo(
        user=UserPublic.model_validate(issued.user),
        csrf_token=csrf_token_for(issued.token, settings.secret_key.get_secret_value()),
        expires_at=issued.expires_at,
    )


async def _enforce(
    limiter: RateLimiter, scope: str, identifier: str, limit: int, window: int
) -> None:
    result = await limiter.hit(scope, identifier, limit, window)
    if not result.allowed:
        raise RateLimitedError(
            f"Too many attempts. Try again in {result.retry_after_seconds} seconds."
        )


@router.post(
    "/register",
    response_model=SessionInfo,
    status_code=status.HTTP_201_CREATED,
    summary="Create a demo account and sign in",
)
async def register(
    payload: RegisterRequest,
    request: Request,
    response: Response,
    settings: SettingsDep,
    service: AuthServiceDep,
    limiter: RateLimiterDep,
) -> SessionInfo:
    if not settings.registration_enabled:
        raise ForbiddenError("Registration is currently disabled.", code="registration_disabled")
    await _enforce(
        limiter,
        "register:ip",
        client_ip(request),
        settings.register_rate_limit,
        settings.register_rate_window_seconds,
    )
    issued = await service.register(
        email=str(payload.email),
        username=payload.username,
        password=payload.password,
        user_agent=request.headers.get("user-agent"),
    )
    _set_session_cookie(response, settings, issued)
    return _session_info(settings, issued)


@router.post("/login", response_model=SessionInfo, summary="Sign in")
async def login(
    payload: LoginRequest,
    request: Request,
    response: Response,
    settings: SettingsDep,
    service: AuthServiceDep,
    limiter: RateLimiterDep,
) -> SessionInfo:
    ip = client_ip(request)
    # Per-IP limit slows credential stuffing; per-account limit slows targeted guessing.
    await _enforce(
        limiter, "login:ip", ip, settings.login_rate_limit, settings.login_rate_window_seconds
    )
    await _enforce(
        limiter,
        "login:account",
        str(payload.email),
        settings.login_rate_limit,
        settings.login_rate_window_seconds,
    )
    issued = await service.login(
        email=str(payload.email),
        password=payload.password,
        user_agent=request.headers.get("user-agent"),
    )
    _set_session_cookie(response, settings, issued)
    return _session_info(settings, issued)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT, summary="Sign out")
async def logout(request: Request, settings: SettingsDep, service: AuthServiceDep) -> Response:
    token = request.cookies.get(settings.session_cookie_name)
    if token:
        await service.logout(token)
    out = Response(status_code=status.HTTP_204_NO_CONTENT)
    out.delete_cookie(
        settings.session_cookie_name,
        path="/",
        httponly=True,
        secure=settings.use_secure_cookies,
        samesite=settings.cookie_samesite,
    )
    return out


@router.get("/me", response_model=SessionInfo, summary="Current session")
async def me(ctx: AuthContextDep, settings: SettingsDep) -> SessionInfo:
    return SessionInfo(
        user=UserPublic.model_validate(ctx.user),
        csrf_token=csrf_token_for(ctx.token, settings.secret_key.get_secret_value()),
        expires_at=ctx.session.expires_at,
    )
