"""Database access for users and sessions. No business rules live here."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import AuthSession, User


class UserRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_id(self, user_id: uuid.UUID) -> User | None:
        return await self.session.get(User, user_id)

    async def get_by_email(self, email: str) -> User | None:
        result = await self.session.execute(select(User).where(User.email == email))
        return result.scalar_one_or_none()

    async def add(self, user: User) -> User:
        """Insert and flush so unique violations surface here (caller handles IntegrityError)."""
        self.session.add(user)
        await self.session.flush()
        return user


class SessionRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def add(self, auth_session: AuthSession) -> AuthSession:
        self.session.add(auth_session)
        await self.session.flush()
        return auth_session

    async def get_with_user(self, token_hash: str) -> tuple[AuthSession, User] | None:
        result = await self.session.execute(
            select(AuthSession, User)
            .join(User, User.id == AuthSession.user_id)
            .where(AuthSession.token_hash == token_hash)
        )
        row = result.one_or_none()
        return (row[0], row[1]) if row else None

    async def touch(self, session_id: uuid.UUID, when: datetime) -> None:
        await self.session.execute(
            update(AuthSession).where(AuthSession.id == session_id).values(last_seen_at=when)
        )

    async def revoke(self, token_hash: str, when: datetime) -> None:
        await self.session.execute(
            update(AuthSession)
            .where(AuthSession.token_hash == token_hash, AuthSession.revoked_at.is_(None))
            .values(revoked_at=when)
        )

    async def revoke_all_for_user(self, user_id: uuid.UUID, when: datetime) -> None:
        await self.session.execute(
            update(AuthSession)
            .where(AuthSession.user_id == user_id, AuthSession.revoked_at.is_(None))
            .values(revoked_at=when)
        )

    async def count_active(self, user_id: uuid.UUID, now: datetime) -> int:
        result = await self.session.execute(
            select(func.count())
            .select_from(AuthSession)
            .where(
                AuthSession.user_id == user_id,
                AuthSession.revoked_at.is_(None),
                AuthSession.expires_at > now,
            )
        )
        return int(result.scalar_one())
