"""Application factory.

Run with:  uvicorn app.main:create_app --factory

A factory (rather than a module-level ``app``) means importing this module has
no side effects, so tests can build apps with explicit settings.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

from app import __version__
from app.api.v1.router import api_router
from app.core.config import Settings, get_settings
from app.core.csrf import CSRFMiddleware
from app.core.errors import register_exception_handlers
from app.core.logging import configure_logging
from app.core.middleware import BodySizeLimitMiddleware, RequestContextMiddleware
from app.core.rate_limit import RateLimiter
from app.db.redis import create_redis
from app.db.session import create_engine, create_session_factory

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    settings: Settings = app.state.settings
    engine = create_engine(settings)
    app.state.engine = engine
    app.state.session_factory = create_session_factory(engine)
    app.state.redis = create_redis(settings)
    app.state.rate_limiter = RateLimiter(app.state.redis)
    logger.info(
        "api started",
        extra={
            "environment": settings.environment,
            "version": __version__,
            "redis_enabled": app.state.redis is not None,
        },
    )
    try:
        yield
    finally:
        if app.state.redis is not None:
            await app.state.redis.aclose()
        await engine.dispose()
        logger.info("api stopped")


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    configure_logging(settings.log_level, settings.log_json)

    app = FastAPI(
        title=settings.app_name,
        version=__version__,
        description=(
            "AURORA demo-credit gaming simulation API. "
            "DEMO CREDITS have no monetary value; there are no deposits or withdrawals."
        ),
        docs_url="/docs" if settings.docs_enabled else None,
        redoc_url="/redoc" if settings.docs_enabled else None,
        openapi_url="/openapi.json" if settings.docs_enabled else None,
        lifespan=lifespan,
    )
    app.state.settings = settings
    # Overwritten by the lifespan; defined here so the app is safe to use in tests
    # that do not run the lifespan and override dependencies instead.
    app.state.session_factory = None
    app.state.redis = None
    app.state.rate_limiter = RateLimiter(None)

    # Middleware order: the LAST one added is the OUTERMOST.
    # request -> RequestContext -> TrustedHost -> CORS -> CSRF -> BodySizeLimit -> app
    # CSRF sits inside CORS so its 403 responses still carry CORS headers.
    app.add_middleware(BodySizeLimitMiddleware, max_bytes=settings.max_request_bytes)
    app.add_middleware(
        CSRFMiddleware,
        secret_key=settings.secret_key.get_secret_value(),
        cookie_name=settings.session_cookie_name,
        allowed_origins=settings.cors_origins,
        exempt_paths=frozenset(
            {f"{settings.api_prefix}/auth/login", f"{settings.api_prefix}/auth/register"}
        ),
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Content-Type", "Idempotency-Key", "X-CSRF-Token", "X-Request-ID"],
        expose_headers=["X-Request-ID"],
        max_age=600,
    )
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.trusted_hosts)
    app.add_middleware(RequestContextMiddleware, quiet_path_suffixes=("/health", "/health/ready"))

    register_exception_handlers(app)
    app.include_router(api_router, prefix=settings.api_prefix)
    return app
