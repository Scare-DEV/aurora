from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

ComponentState = Literal["ok", "error", "disabled"]


class HealthResponse(BaseModel):
    """Liveness: the process is up. Performs no dependency checks."""

    status: Literal["ok"]
    service: str
    version: str


class ReadinessResponse(BaseModel):
    """Readiness: whether the API can serve traffic.

    ``ok``          all configured dependencies are healthy
    ``degraded``    the database is healthy but an optional dependency (Redis) is not
    ``unavailable`` the database is unreachable (HTTP 503)
    """

    status: Literal["ok", "degraded", "unavailable"]
    version: str
    checks: dict[str, ComponentState]
