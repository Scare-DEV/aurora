"""Auth and user DTOs. Database models are never returned directly."""

from __future__ import annotations

import re
import uuid
from datetime import datetime
from typing import Annotated

from pydantic import (
    AfterValidator,
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
    StringConstraints,
    model_validator,
)

USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_]{3,24}$")
MIN_PASSWORD_LENGTH = 10
MAX_PASSWORD_LENGTH = 128


def _normalize_email(value: str) -> str:
    return value.strip().lower()


def _valid_username(value: str) -> str:
    value = value.strip()
    if not USERNAME_PATTERN.fullmatch(value):
        raise ValueError("Username must be 3-24 characters: letters, digits or underscore.")
    return value


NormalizedEmail = Annotated[EmailStr, AfterValidator(_normalize_email)]
Username = Annotated[str, AfterValidator(_valid_username)]
Password = Annotated[
    str,
    StringConstraints(min_length=MIN_PASSWORD_LENGTH, max_length=MAX_PASSWORD_LENGTH),
]


class StrictModel(BaseModel):
    # Unknown fields (e.g. "role": "admin") are rejected, never silently ignored.
    model_config = ConfigDict(extra="forbid")


class RegisterRequest(StrictModel):
    email: NormalizedEmail
    username: Username
    password: Password

    @model_validator(mode="after")
    def _password_not_identity(self) -> RegisterRequest:
        lowered = self.password.lower()
        if lowered in {self.username.lower(), str(self.email).lower()}:
            raise ValueError("Password must not equal your username or email.")
        return self


class LoginRequest(StrictModel):
    email: NormalizedEmail
    # No length policy on login: never leak the policy or reject legacy passwords early.
    password: Annotated[str, Field(min_length=1, max_length=MAX_PASSWORD_LENGTH)]


class UserPublic(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    email: str
    username: str
    role: str
    status: str
    created_at: datetime
    last_login_at: datetime | None


class SessionInfo(BaseModel):
    """Returned by login and /auth/me. ``csrf_token`` must be sent as X-CSRF-Token."""

    user: UserPublic
    csrf_token: str
    expires_at: datetime


class UpdateProfileRequest(StrictModel):
    username: Username | None = None

    @model_validator(mode="after")
    def _at_least_one_field(self) -> UpdateProfileRequest:
        if self.username is None:
            raise ValueError("Provide at least one field to update.")
        return self
