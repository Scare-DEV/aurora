"""Optional Redis client (rate limiting, caching, short-lived coordination only)."""

from __future__ import annotations

from redis.asyncio import Redis

from app.core.config import Settings


def create_redis(settings: Settings) -> Redis | None:
    """Return a client, or ``None`` when Redis is not configured.

    ``from_url`` does not open a connection; failures surface on first use,
    which the readiness probe reports as ``error`` without crashing the API.
    """
    if settings.redis_url is None:
        return None
    return Redis.from_url(
        settings.redis_url,
        decode_responses=True,
        socket_connect_timeout=2,
        socket_timeout=2,
    )
