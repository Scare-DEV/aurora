"""Registration, login, session lifecycle."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import Settings
from app.core.errors import ConflictError, ForbiddenError, UnauthenticatedError
from app.core.security import (
    hash_password_async,
    hash_token,
    new_session_token,
    password_needs_rehash,
    verify_password_async,
)
from app.models.user import AuthSession, User, UserRole, UserStatus
from app.repositories.user_repository import SessionRepository, UserRepository

# Write last_seen at most this often, to avoid a database write on every request.
_TOUCH_INTERVAL = timedelta(minutes=1)
_USER_AGENT_MAX = 256


@dataclass(frozen=True)
class IssuedSession:
    user: User
    token: str  # raw cookie value: returned once, never stored
    expires_at: datetime


@dataclass(frozen=True)
class ResolvedSession:
    user: User
    session: AuthSession


def _now() -> datetime:
    return datetime.now(UTC)


class AuthService:
    def __init__(self, session: AsyncSession, settings: Settings) -> None:
        self.db = session
        self.settings = settings
        self.users = UserRepository(session)
        self.sessions = SessionRepository(session)

    async def register(
        self, *, email: str, username: str, password: str, user_agent: str | None
    ) -> IssuedSession:
        password_hash = await hash_password_async(password)
        # The role is fixed here: nothing from the request can influence it.
        user = User(
            email=email,
            username=username,
            password_hash=password_hash,
            role=UserRole.PLAYER.value,
            status=UserStatus.ACTIVE.value,
        )
        try:
            await self.users.add(user)
            issued = await self._issue_session(user, user_agent)
            user.last_login_at = _now()
            await self.db.commit()
        except IntegrityError as exc:
            await self.db.rollback()
            # One generic message for email and username collisions.
            raise ConflictError(
                "That email or username is not available.", code="account_unavailable"
            ) from exc
        return issued

    async def login(self, *, email: str, password: str, user_agent: str | None) -> IssuedSession:
        user = await self.users.get_by_email(email)
        stored_hash = user.password_hash if user is not None else None
        valid = await verify_password_async(stored_hash, password)
        if user is None or not valid or user.status == UserStatus.DELETED.value:
            raise UnauthenticatedError("Invalid email or password.", code="invalid_credentials")
        if user.status != UserStatus.ACTIVE.value:
            # Only reached with the correct password, so this does not enumerate accounts.
            raise ForbiddenError("This account is not active.", code="account_inactive")

        if stored_hash is not None and password_needs_rehash(stored_hash):
            user.password_hash = await hash_password_async(password)
        issued = await self._issue_session(user, user_agent)
        user.last_login_at = _now()
        await self.db.commit()
        return issued

    async def resolve_session(self, token: str) -> ResolvedSession | None:
        found = await self.sessions.get_with_user(hash_token(token))
        if found is None:
            return None
        auth_session, user = found
        now = _now()
        if (
            auth_session.revoked_at is not None
            or auth_session.expires_at <= now
            or auth_session.last_seen_at
            <= now - timedelta(seconds=self.settings.session_idle_seconds)
            or user.status != UserStatus.ACTIVE.value
        ):
            return None
        if now - auth_session.last_seen_at >= _TOUCH_INTERVAL:
            await self.sessions.touch(auth_session.id, now)
            await self.db.commit()
        return ResolvedSession(user=user, session=auth_session)

    async def logout(self, token: str) -> None:
        await self.sessions.revoke(hash_token(token), _now())
        await self.db.commit()

    async def update_username(self, user: User, username: str) -> User:
        user.username = username
        try:
            await self.db.flush()
            await self.db.commit()
        except IntegrityError as exc:
            await self.db.rollback()
            raise ConflictError(
                "That username is not available.", code="account_unavailable"
            ) from exc
        return user

    async def _issue_session(self, user: User, user_agent: str | None) -> IssuedSession:
        token = new_session_token()
        expires_at = _now() + timedelta(seconds=self.settings.session_ttl_seconds)
        await self.sessions.add(
            AuthSession(
                user_id=user.id,
                token_hash=hash_token(token),
                expires_at=expires_at,
                user_agent=user_agent[:_USER_AGENT_MAX] if user_agent else None,
            )
        )
        return IssuedSession(user=user, token=token, expires_at=expires_at)
