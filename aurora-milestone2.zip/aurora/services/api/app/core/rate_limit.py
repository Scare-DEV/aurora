"""Fixed-window rate limiting: Redis when configured, in-process fallback otherwise.

The in-process fallback is per-worker and only suitable for development and tests;
production should configure Redis so limits hold across workers.
"""

from __future__ import annotations

import hashlib
import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from redis.asyncio import Redis

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class RateLimitResult:
    allowed: bool
    retry_after_seconds: int


def hashed_key(*parts: str) -> str:
    """Identifiers (emails, IPs) are hashed so they never appear in Redis keys or logs."""
    return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:32]


class RateLimiter:
    def __init__(self, redis: Redis | None) -> None:
        self._redis = redis
        self._memory: dict[str, tuple[int, float]] = {}

    async def hit(
        self, scope: str, identifier: str, limit: int, window_seconds: int
    ) -> RateLimitResult:
        key = f"aurora:rl:{scope}:{hashed_key(identifier)}"
        if self._redis is not None:
            try:
                return await self._hit_redis(self._redis, key, limit, window_seconds)
            except Exception as exc:  # Redis outage must not take auth down; fall back locally.
                logger.warning("rate limit redis error", extra={"error_type": type(exc).__name__})
        return self._hit_memory(key, limit, window_seconds)

    @staticmethod
    async def _hit_redis(
        redis: Redis, key: str, limit: int, window_seconds: int
    ) -> RateLimitResult:
        pipe = redis.pipeline()
        pipe.incr(key)
        pipe.expire(key, window_seconds, nx=True)
        pipe.ttl(key)
        count, _, ttl = await pipe.execute()
        retry = max(int(ttl), 1)
        return RateLimitResult(allowed=int(count) <= limit, retry_after_seconds=retry)

    def _hit_memory(self, key: str, limit: int, window_seconds: int) -> RateLimitResult:
        now = time.monotonic()
        count, reset_at = self._memory.get(key, (0, now + window_seconds))
        if now >= reset_at:
            count, reset_at = 0, now + window_seconds
        count += 1
        self._memory[key] = (count, reset_at)
        if len(self._memory) > 10_000:  # bound memory: drop expired windows
            self._memory = {k: v for k, v in self._memory.items() if v[1] > now}
        return RateLimitResult(
            allowed=count <= limit, retry_after_seconds=max(int(reset_at - now), 1)
        )
