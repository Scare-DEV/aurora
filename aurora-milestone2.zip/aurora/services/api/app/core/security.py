"""Password hashing, session tokens and CSRF tokens.

* Passwords: Argon2id (argon2-cffi defaults follow the RFC 9106 low-memory profile).
  Hashing is CPU/memory heavy, so callers use the async helpers, which run in a thread.
* Session tokens: 256 bits from ``secrets``; only the SHA-256 hash is stored.
* CSRF tokens: HMAC-SHA256(secret_key, session token). Bound to the session, stateless.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets

from anyio import to_thread
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

_hasher = PasswordHasher()  # Argon2id by default

# Verified against when a login names an unknown account, so response time does not
# reveal whether the account exists.
_DUMMY_HASH = _hasher.hash("aurora-dummy-password-for-timing")


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password_hash: str, password: str) -> bool:
    try:
        return _hasher.verify(password_hash, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def password_needs_rehash(password_hash: str) -> bool:
    try:
        return _hasher.check_needs_rehash(password_hash)
    except InvalidHashError:
        return True


async def hash_password_async(password: str) -> str:
    return await to_thread.run_sync(hash_password, password)


async def verify_password_async(password_hash: str | None, password: str) -> bool:
    """Constant-effort verification: unknown accounts still pay for one Argon2 verify."""
    if password_hash is None:
        await to_thread.run_sync(verify_password, _DUMMY_HASH, password)
        return False
    return await to_thread.run_sync(verify_password, password_hash, password)


def new_session_token() -> str:
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def csrf_token_for(session_token: str, secret_key: str) -> str:
    return hmac.new(
        secret_key.encode("utf-8"), b"csrf:" + session_token.encode("utf-8"), hashlib.sha256
    ).hexdigest()


def csrf_token_valid(candidate: str | None, session_token: str, secret_key: str) -> bool:
    if not candidate:
        return False
    return hmac.compare_digest(candidate, csrf_token_for(session_token, secret_key))
