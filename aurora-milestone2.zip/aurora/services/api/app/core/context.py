"""Request-scoped context shared by logging, middleware and error handling.

Standard library only, so it can be imported from anywhere without cycles.
"""

from __future__ import annotations

import re
import uuid
from contextvars import ContextVar

request_id_ctx: ContextVar[str | None] = ContextVar("request_id", default=None)

# Inbound request IDs are only trusted when they look like opaque identifiers.
# This blocks log injection (newlines, control characters) and oversized values.
_REQUEST_ID_RE = re.compile(r"[A-Za-z0-9_-]{8,64}")


def new_request_id() -> str:
    return uuid.uuid4().hex


def sanitize_request_id(candidate: str | None) -> str:
    """Return ``candidate`` if it is a safe opaque identifier, else a fresh ID."""
    if candidate is not None and _REQUEST_ID_RE.fullmatch(candidate):
        return candidate
    return new_request_id()


def get_request_id() -> str | None:
    return request_id_ctx.get()
