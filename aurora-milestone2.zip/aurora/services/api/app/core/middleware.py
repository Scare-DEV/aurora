"""Pure ASGI middleware: request IDs, access logging, security headers, body limits.

Implemented as plain ASGI (not ``BaseHTTPMiddleware``) so that context
variables propagate correctly and streaming bodies can be size-limited.
"""

from __future__ import annotations

import logging
import time
from http import HTTPStatus

from starlette.datastructures import Headers, MutableHeaders
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.core.context import request_id_ctx, sanitize_request_id
from app.core.errors import PayloadTooLargeError, error_response

logger = logging.getLogger("aurora.access")

_SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "Cache-Control": "no-store",
}
_API_CSP = "default-src 'none'; frame-ancestors 'none'"
# Swagger UI / ReDoc load scripts and styles, so the strict API CSP must not apply to them.
_DOCS_PREFIXES = ("/docs", "/redoc")


class RequestContextMiddleware:
    """Assign a request ID, add security headers, and write one access-log line."""

    def __init__(self, app: ASGIApp, quiet_path_suffixes: tuple[str, ...] = ()) -> None:
        self.app = app
        self.quiet_path_suffixes = quiet_path_suffixes

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request_id = sanitize_request_id(Headers(scope=scope).get("x-request-id"))
        scope.setdefault("state", {})["request_id"] = request_id
        token = request_id_ctx.set(request_id)
        path: str = scope["path"]
        is_docs = path.startswith(_DOCS_PREFIXES)
        started = time.perf_counter()
        status_code = HTTPStatus.INTERNAL_SERVER_ERROR.value

        async def send_wrapper(message: Message) -> None:
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = message["status"]
                headers = MutableHeaders(scope=message)
                headers["X-Request-ID"] = request_id
                for name, value in _SECURITY_HEADERS.items():
                    headers.setdefault(name, value)
                if not is_docs:
                    headers.setdefault("Content-Security-Policy", _API_CSP)
            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            duration_ms = round((time.perf_counter() - started) * 1000, 2)
            level = logging.DEBUG if path.endswith(self.quiet_path_suffixes) else logging.INFO
            # Path only: query strings can carry sensitive values and are never logged.
            logger.log(
                level,
                "request",
                extra={
                    "method": scope["method"],
                    "path": path,
                    "status": status_code,
                    "duration_ms": duration_ms,
                },
            )
            request_id_ctx.reset(token)


class BodySizeLimitMiddleware:
    """Reject request bodies larger than ``max_bytes`` with HTTP 413.

    Checks the declared ``Content-Length`` up front and also counts bytes as
    they stream, so chunked uploads without a Content-Length are limited too.
    """

    def __init__(self, app: ASGIApp, max_bytes: int) -> None:
        self.app = app
        self.max_bytes = max_bytes

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        declared = Headers(scope=scope).get("content-length")
        if declared is not None and declared.isdigit() and int(declared) > self.max_bytes:
            await self._reject(scope, receive, send)
            return

        received = 0
        response_started = False

        async def limited_receive() -> Message:
            nonlocal received
            message = await receive()
            if message["type"] == "http.request":
                received += len(message.get("body", b""))
                if received > self.max_bytes:
                    # An HTTPException subclass, so FastAPI's body parsing re-raises it
                    # and the registered handler renders the 413 error schema.
                    raise PayloadTooLargeError(self.max_bytes)
            return message

        async def tracking_send(message: Message) -> None:
            nonlocal response_started
            if message["type"] == "http.response.start":
                response_started = True
            await send(message)

        try:
            await self.app(scope, limited_receive, tracking_send)
        except PayloadTooLargeError:
            # Fallback for when the limit is hit outside FastAPI's own exception handling.
            if response_started:
                raise
            await self._reject(scope, receive, send)

    async def _reject(self, scope: Scope, receive: Receive, send: Send) -> None:
        request_id = scope.get("state", {}).get("request_id") or sanitize_request_id(None)
        error = PayloadTooLargeError(self.max_bytes)
        response = error_response(
            request_id,
            HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
            "payload_too_large",
            str(error.detail),
        )
        await response(scope, receive, send)
