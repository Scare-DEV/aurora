"""CSRF protection for cookie-authenticated, state-changing requests (pure ASGI).

Strategy (documented in docs/security.md):
1. SameSite=Lax session cookie (not sent on cross-site POST/PATCH/DELETE).
2. ``Origin`` header, when present on an unsafe request, must be in the CORS allowlist.
3. A request carrying the session cookie must send ``X-CSRF-Token`` equal to
   HMAC(secret, session token). The token is returned in the login / ``/auth/me`` JSON
   bodies, which a cross-site page cannot read.

Login and registration are exempt from (3) because they establish the session; they are
still covered by (1) and (2).
"""

from __future__ import annotations

from http import HTTPStatus

from starlette.datastructures import Headers
from starlette.requests import Request
from starlette.types import ASGIApp, Receive, Scope, Send

from app.core.errors import error_response
from app.core.security import csrf_token_valid

_SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS", "TRACE"})


class CSRFMiddleware:
    def __init__(
        self,
        app: ASGIApp,
        *,
        secret_key: str,
        cookie_name: str,
        allowed_origins: list[str],
        exempt_paths: frozenset[str],
    ) -> None:
        self.app = app
        self.secret_key = secret_key
        self.cookie_name = cookie_name
        self.allowed_origins = frozenset(allowed_origins)
        self.exempt_paths = exempt_paths

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope["method"] in _SAFE_METHODS:
            await self.app(scope, receive, send)
            return

        headers = Headers(scope=scope)
        origin = headers.get("origin")
        if origin is not None and origin not in self.allowed_origins:
            await self._reject(scope, receive, send, "Cross-origin request rejected.")
            return

        if scope["path"] not in self.exempt_paths:
            session_token = Request(scope).cookies.get(self.cookie_name)
            if session_token and not csrf_token_valid(
                headers.get("x-csrf-token"), session_token, self.secret_key
            ):
                await self._reject(scope, receive, send, "Missing or invalid CSRF token.")
                return

        await self.app(scope, receive, send)

    async def _reject(self, scope: Scope, receive: Receive, send: Send, message: str) -> None:
        request_id = scope.get("state", {}).get("request_id", "unknown")
        response = error_response(request_id, HTTPStatus.FORBIDDEN, "csrf_failed", message)
        await response(scope, receive, send)
