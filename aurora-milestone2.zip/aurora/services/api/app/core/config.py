"""Environment-based configuration.

All settings come from environment variables (or a local ``.env`` file in
development). There is deliberately no default for ``SECRET_KEY`` or
``DATABASE_URL``: the service refuses to start without them.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Annotated, Literal, Self

from pydantic import Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

_PLACEHOLDER_FRAGMENTS = ("change-me", "changeme", "dev-only", "example", "secret")
_MIN_PRODUCTION_SECRET_LENGTH = 32


def _split_csv(value: object) -> object:
    """Accept ``"a, b"`` from the environment as well as a real list."""
    if isinstance(value, str):
        return [item.strip() for item in value.split(",") if item.strip()]
    return value


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # --- Application -------------------------------------------------------
    environment: Literal["development", "test", "production"] = "development"
    app_name: str = "AURORA API"
    api_prefix: str = "/api/v1"
    docs_enabled: bool = True
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    log_json: bool = True

    # --- Data stores -------------------------------------------------------
    # PostgreSQL is the only supported primary database (async driver: asyncpg).
    database_url: str
    db_pool_size: int = Field(default=5, ge=1, le=100)
    db_max_overflow: int = Field(default=10, ge=0, le=100)
    db_pool_timeout_seconds: float = Field(default=10.0, gt=0, le=60)
    db_echo: bool = False
    # Redis is optional: rate limiting, caching, short-lived coordination only.
    redis_url: str | None = None

    # --- Security ----------------------------------------------------------
    secret_key: SecretStr
    # Strict allowlists. Wildcards are rejected.
    cors_origins: Annotated[list[str], NoDecode] = Field(
        default_factory=lambda: ["http://localhost:3000"]
    )
    trusted_hosts: Annotated[list[str], NoDecode] = Field(
        default_factory=lambda: ["localhost", "127.0.0.1"]
    )
    max_request_bytes: int = Field(default=1_048_576, ge=1_024, le=16_777_216)

    # --- Sessions / auth ---------------------------------------------------
    session_cookie_name: str = "aurora_session"
    session_ttl_seconds: int = Field(default=7 * 24 * 3600, ge=300, le=30 * 24 * 3600)
    session_idle_seconds: int = Field(default=24 * 3600, ge=300, le=30 * 24 * 3600)
    # None = Secure only in production (browsers treat http://localhost as secure anyway).
    cookie_secure: bool | None = None
    cookie_samesite: Literal["lax", "strict"] = "lax"
    registration_enabled: bool = True
    # Rate limits: "<count>/<window seconds>" semantics, kept as two ints each.
    login_rate_limit: int = Field(default=10, ge=1)
    login_rate_window_seconds: int = Field(default=300, ge=1)
    register_rate_limit: int = Field(default=5, ge=1)
    register_rate_window_seconds: int = Field(default=3600, ge=1)

    @field_validator("cors_origins", "trusted_hosts", mode="before")
    @classmethod
    def _parse_csv(cls, value: object) -> object:
        return _split_csv(value)

    @field_validator("database_url")
    @classmethod
    def _require_postgres_asyncpg(cls, value: str) -> str:
        if not value.startswith("postgresql+asyncpg://"):
            raise ValueError(
                "DATABASE_URL must use the 'postgresql+asyncpg://' scheme "
                "(PostgreSQL is the only supported primary database)"
            )
        return value

    @field_validator("redis_url", mode="before")
    @classmethod
    def _empty_redis_url_is_none(cls, value: object) -> object:
        if isinstance(value, str) and not value.strip():
            return None
        return value

    @field_validator("cors_origins")
    @classmethod
    def _no_wildcard_origins(cls, value: list[str]) -> list[str]:
        if any(origin == "*" or "*" in origin for origin in value):
            raise ValueError(
                "CORS_ORIGINS must be an explicit allowlist; wildcards are not allowed"
            )
        return value

    @field_validator("trusted_hosts")
    @classmethod
    def _non_empty_trusted_hosts(cls, value: list[str]) -> list[str]:
        if not value:
            raise ValueError("TRUSTED_HOSTS must contain at least one host")
        return value

    @model_validator(mode="after")
    def _production_guards(self) -> Self:
        if self.environment == "production":
            secret = self.secret_key.get_secret_value()
            if len(secret) < _MIN_PRODUCTION_SECRET_LENGTH or any(
                fragment in secret.lower() for fragment in _PLACEHOLDER_FRAGMENTS
            ):
                raise ValueError(
                    "SECRET_KEY is too short or looks like a placeholder; production "
                    f"requires at least {_MIN_PRODUCTION_SECRET_LENGTH} random characters"
                )
        return self

    @property
    def use_secure_cookies(self) -> bool:
        if self.cookie_secure is not None:
            return self.cookie_secure
        return self.environment == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]  # values come from the environment
