"""Consistent API error model and exception handlers.

Every error response has the shape::

    {"code": "...", "message": "...", "request_id": "...", "field_errors": [...]}

``field_errors`` is present only for validation failures. Internal exception
details and stack traces are logged server-side and never returned.
"""

from __future__ import annotations

import logging
from http import HTTPStatus
from typing import Any, cast

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.context import get_request_id, new_request_id

logger = logging.getLogger(__name__)

_LOCATION_PREFIXES = frozenset({"body", "query", "path", "header", "cookie"})


class FieldError(BaseModel):
    field: str
    message: str


class ErrorResponse(BaseModel):
    code: str
    message: str
    request_id: str
    field_errors: list[FieldError] | None = None


class AppError(Exception):
    """Base class for expected, user-facing errors raised by services and routes."""

    status_code: int = HTTPStatus.INTERNAL_SERVER_ERROR
    code: str = "internal_error"
    default_message: str = "An unexpected error occurred."

    def __init__(self, message: str | None = None, *, code: str | None = None) -> None:
        self.message = message or self.default_message
        if code is not None:
            self.code = code
        super().__init__(self.message)


class PayloadTooLargeError(HTTPException):
    """HTTP 413, raised while a request body is being read.

    This deliberately subclasses ``HTTPException``: FastAPI converts any *other*
    exception raised during body parsing into a generic 400, but re-raises
    ``HTTPException`` untouched.
    """

    def __init__(self, max_bytes: int) -> None:
        super().__init__(
            status_code=HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
            detail=f"The request body exceeds the maximum allowed size of {max_bytes} bytes.",
        )


class InvalidStateError(AppError):
    status_code = HTTPStatus.BAD_REQUEST
    code = "invalid_state"
    default_message = "The requested action is not valid in the current state."


class UnauthenticatedError(AppError):
    status_code = HTTPStatus.UNAUTHORIZED
    code = "unauthenticated"
    default_message = "Authentication is required."


class ForbiddenError(AppError):
    status_code = HTTPStatus.FORBIDDEN
    code = "forbidden"
    default_message = "You do not have permission to perform this action."


class NotFoundError(AppError):
    status_code = HTTPStatus.NOT_FOUND
    code = "not_found"
    default_message = "The requested resource was not found."


class ConflictError(AppError):
    status_code = HTTPStatus.CONFLICT
    code = "conflict"
    default_message = "The request conflicts with the current state of the resource."


class RateLimitedError(AppError):
    status_code = HTTPStatus.TOO_MANY_REQUESTS
    code = "rate_limited"
    default_message = "Too many requests. Please try again later."


_STATUS_CODES: dict[int, str] = {
    HTTPStatus.BAD_REQUEST: "bad_request",
    HTTPStatus.UNAUTHORIZED: "unauthenticated",
    HTTPStatus.FORBIDDEN: "forbidden",
    HTTPStatus.NOT_FOUND: "not_found",
    HTTPStatus.METHOD_NOT_ALLOWED: "method_not_allowed",
    HTTPStatus.CONFLICT: "conflict",
    HTTPStatus.REQUEST_ENTITY_TOO_LARGE: "payload_too_large",
    HTTPStatus.TOO_MANY_REQUESTS: "rate_limited",
}


def _request_id_for(request: Request) -> str:
    state_value = getattr(request.state, "request_id", None)
    if isinstance(state_value, str) and state_value:
        return state_value
    return get_request_id() or new_request_id()


def error_response(
    request_id: str,
    status_code: int,
    code: str,
    message: str,
    field_errors: list[FieldError] | None = None,
    headers: dict[str, str] | None = None,
) -> JSONResponse:
    body = ErrorResponse(
        code=code, message=message, request_id=request_id, field_errors=field_errors
    )
    merged_headers = {"X-Request-ID": request_id, **(headers or {})}
    return JSONResponse(
        status_code=status_code,
        content=body.model_dump(mode="json", exclude_none=True),
        headers=merged_headers,
    )


def _field_errors(errors: list[Any]) -> list[FieldError]:
    """Convert Pydantic errors without echoing the submitted input values."""
    result: list[FieldError] = []
    for err in errors:
        loc = [str(part) for part in err.get("loc", ())]
        if loc and loc[0] in _LOCATION_PREFIXES:
            loc = loc[1:]
        result.append(FieldError(field=".".join(loc) or "request", message=str(err.get("msg", ""))))
    return result


# Starlette types every handler as ``(Request, Exception)``; each handler below is only
# registered for the exception class it narrows to, so the casts are safe.
async def _handle_app_error(request: Request, exc: Exception) -> JSONResponse:
    error = cast(AppError, exc)
    return error_response(_request_id_for(request), error.status_code, error.code, error.message)


async def _handle_validation_error(request: Request, exc: Exception) -> JSONResponse:
    error = cast(RequestValidationError, exc)
    return error_response(
        _request_id_for(request),
        HTTPStatus.UNPROCESSABLE_ENTITY,
        "validation_error",
        "The request could not be validated.",
        field_errors=_field_errors(list(error.errors())),
    )


async def _handle_http_exception(request: Request, exc: Exception) -> JSONResponse:
    http_error = cast(StarletteHTTPException, exc)
    status_code = http_error.status_code
    if isinstance(http_error, PayloadTooLargeError):
        message = str(http_error.detail)
    else:
        # Standard phrase only: arbitrary ``detail`` strings could leak internals.
        try:
            message = HTTPStatus(status_code).phrase
        except ValueError:
            message = "Request failed."
    code = _STATUS_CODES.get(status_code, "http_error")
    return error_response(
        _request_id_for(request),
        status_code,
        code,
        message,
        headers=dict(http_error.headers) if http_error.headers else None,
    )


async def _handle_unexpected_error(request: Request, exc: Exception) -> JSONResponse:
    request_id = _request_id_for(request)
    logger.error(
        "unhandled exception",
        exc_info=(type(exc), exc, exc.__traceback__),
        extra={"path": request.url.path, "method": request.method, "request_id_hint": request_id},
    )
    return error_response(
        request_id,
        HTTPStatus.INTERNAL_SERVER_ERROR,
        "internal_error",
        "An unexpected error occurred. Quote the request ID if you contact support.",
    )


def register_exception_handlers(app: FastAPI) -> None:
    app.add_exception_handler(AppError, _handle_app_error)
    app.add_exception_handler(RequestValidationError, _handle_validation_error)
    app.add_exception_handler(StarletteHTTPException, _handle_http_exception)
    app.add_exception_handler(Exception, _handle_unexpected_error)
