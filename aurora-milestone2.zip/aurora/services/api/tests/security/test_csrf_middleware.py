"""CSRF middleware in isolation (needs starlette + httpx; no database)."""

from collections.abc import AsyncIterator

import httpx
import pytest
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from app.core.csrf import CSRFMiddleware
from app.core.security import csrf_token_for

SECRET = "Zk3vQ9rT7pLx2WnB5dHs8YcF1mJg6AeU4oIy0Rt"
COOKIE = "aurora_session"
SESSION = "raw-session-token"
ORIGIN = "http://localhost:3000"


async def ok(_: Request) -> JSONResponse:
    return JSONResponse({"ok": True})


@pytest.fixture
async def client() -> AsyncIterator[httpx.AsyncClient]:
    app = Starlette(
        routes=[
            Route("/change", ok, methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"]),
            Route("/login", ok, methods=["POST"]),
        ]
    )
    app.add_middleware(
        CSRFMiddleware,
        secret_key=SECRET,
        cookie_name=COOKIE,
        allowed_origins=[ORIGIN],
        exempt_paths=frozenset({"/login"}),
    )
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://testserver"
    ) as http:
        yield http


async def test_safe_methods_never_need_a_token(client: httpx.AsyncClient) -> None:
    r = await client.get("/change", cookies={COOKIE: SESSION})
    assert r.status_code == 200


@pytest.mark.parametrize("method", ["POST", "PATCH", "DELETE"])
async def test_unsafe_request_with_session_cookie_requires_token(
    client: httpx.AsyncClient, method: str
) -> None:
    r = await client.request(method, "/change", cookies={COOKIE: SESSION})
    assert r.status_code == 403
    assert r.json()["code"] == "csrf_failed"


async def test_valid_token_passes(client: httpx.AsyncClient) -> None:
    token = csrf_token_for(SESSION, SECRET)
    r = await client.post("/change", cookies={COOKIE: SESSION}, headers={"X-CSRF-Token": token})
    assert r.status_code == 200


async def test_token_from_another_session_is_rejected(client: httpx.AsyncClient) -> None:
    other = csrf_token_for("some-other-session", SECRET)
    r = await client.post("/change", cookies={COOKIE: SESSION}, headers={"X-CSRF-Token": other})
    assert r.status_code == 403


async def test_tampered_token_is_rejected(client: httpx.AsyncClient) -> None:
    token = csrf_token_for(SESSION, SECRET)
    r = await client.post(
        "/change", cookies={COOKIE: SESSION}, headers={"X-CSRF-Token": token[:-2] + "00"}
    )
    assert r.status_code == 403


async def test_foreign_origin_is_rejected_even_with_valid_token(
    client: httpx.AsyncClient,
) -> None:
    token = csrf_token_for(SESSION, SECRET)
    r = await client.post(
        "/change",
        cookies={COOKIE: SESSION},
        headers={"X-CSRF-Token": token, "Origin": "http://evil.example"},
    )
    assert r.status_code == 403


async def test_allowed_origin_with_valid_token_passes(client: httpx.AsyncClient) -> None:
    token = csrf_token_for(SESSION, SECRET)
    r = await client.post(
        "/change", cookies={COOKIE: SESSION}, headers={"X-CSRF-Token": token, "Origin": ORIGIN}
    )
    assert r.status_code == 200


async def test_login_is_exempt_from_token_but_not_from_origin_check(
    client: httpx.AsyncClient,
) -> None:
    # Stale cookie, no token: allowed on the exempt path.
    assert (await client.post("/login", cookies={COOKIE: SESSION})).status_code == 200
    bad = await client.post(
        "/login", cookies={COOKIE: SESSION}, headers={"Origin": "http://evil.example"}
    )
    assert bad.status_code == 403


async def test_request_without_session_cookie_is_not_blocked(client: httpx.AsyncClient) -> None:
    # No ambient credentials, so there is nothing for CSRF to abuse.
    assert (await client.post("/change")).status_code == 200
