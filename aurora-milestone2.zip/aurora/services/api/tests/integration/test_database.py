"""Tests that use the real asyncpg driver.

``test_readiness_reports_503_when_postgres_is_unreachable`` needs no running
database (connection refused is the scenario). The other test needs a real
PostgreSQL and is skipped unless TEST_DATABASE_URL is set; a skip is NOT a pass.
"""

import os

import httpx
import pytest
from sqlalchemy import text

from app.core.config import Settings
from app.main import create_app

pytestmark = pytest.mark.integration

TEST_DATABASE_URL = os.environ.get("TEST_DATABASE_URL")
SECRET = "Zk3vQ9rT7pLx2WnB5dHs8YcF1mJg6AeU4oIy0Rt"


def make_settings(database_url: str) -> Settings:
    return Settings(  # type: ignore[call-arg]
        _env_file=None,
        environment="test",
        database_url=database_url,
        secret_key=SECRET,
        trusted_hosts=["testserver"],
        log_json=False,
    )


@pytest.mark.skipif(not TEST_DATABASE_URL, reason="TEST_DATABASE_URL is not set")
async def test_readiness_ok_and_session_timezone_is_utc() -> None:
    assert TEST_DATABASE_URL is not None
    app = create_app(make_settings(TEST_DATABASE_URL))
    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
            response = await client.get("/api/v1/health/ready")
        assert response.status_code == 200
        assert response.json()["checks"]["database"] == "ok"

        async with app.state.session_factory() as session:
            timezone = (await session.execute(text("SHOW timezone"))).scalar_one()
        assert timezone == "UTC"


async def test_readiness_reports_503_when_postgres_is_unreachable() -> None:
    # Port 1 is closed on any normal host, so asyncpg fails fast with a real error.
    app = create_app(make_settings("postgresql+asyncpg://u:p@127.0.0.1:1/db"))
    async with app.router.lifespan_context(app):
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
            response = await client.get("/api/v1/health/ready")
    assert response.status_code == 503
    body = response.json()
    assert body["status"] == "unavailable"
    assert body["checks"]["database"] == "error"
