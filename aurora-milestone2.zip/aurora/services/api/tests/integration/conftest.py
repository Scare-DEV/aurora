"""PostgreSQL-backed fixtures.

Set TEST_DATABASE_URL to a DEDICATED, EMPTY database (for example ``aurora_test``).
The schema is created by running the real ``alembic upgrade head`` CLI against it, so the
migrations themselves are under test. Never point this at a database you care about:
the fixture runs ``alembic downgrade base`` first, which drops every AURORA table.
"""

from __future__ import annotations

import os
import subprocess
import sys
from collections.abc import AsyncIterator, Iterator
from pathlib import Path
from typing import Any

import httpx
import pytest
from fastapi import FastAPI
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine

from app.core.config import Settings
from app.main import create_app

API_DIR = Path(__file__).resolve().parents[2]
SECRET = "Zk3vQ9rT7pLx2WnB5dHs8YcF1mJg6AeU4oIy0Rt"
ORIGIN = "http://localhost:3000"


def database_url() -> str:
    url = os.environ.get("TEST_DATABASE_URL")
    if not url:
        pytest.skip("TEST_DATABASE_URL is not set (a skip is NOT a pass)")
    return url


def alembic(*args: str) -> subprocess.CompletedProcess[str]:
    env = {
        **os.environ,
        "DATABASE_URL": database_url(),
        "SECRET_KEY": SECRET,
        "ENVIRONMENT": "test",
    }
    return subprocess.run(  # noqa: S603  (fixed argv, test-only)
        [sys.executable, "-m", "alembic", *args],
        cwd=API_DIR,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )


@pytest.fixture(scope="session")
def migrated_database() -> Iterator[str]:
    url = database_url()
    alembic("downgrade", "base")  # best effort: clears a previous run's schema
    result = alembic("upgrade", "head")
    assert result.returncode == 0, f"alembic upgrade head failed:\n{result.stderr}"
    yield url


@pytest.fixture
async def engine(migrated_database: str) -> AsyncIterator[AsyncEngine]:
    eng = create_async_engine(migrated_database)
    async with eng.begin() as conn:
        # The ledger's append-only trigger (correctly) blocks DELETE. Test cleanup is the one
        # place that switches it off, inside this transaction, in the dedicated test database.
        await conn.execute(text("ALTER TABLE wallet_ledger DISABLE TRIGGER USER"))
        for table in (
            "wallet_ledger",
            "game_rounds",
            "wallets",
            "favorites",
            "user_achievements",
            "audit_logs",
            "sessions",
            "users",
        ):
            await conn.execute(text(f"DELETE FROM {table}"))  # noqa: S608  (fixed table names)
        await conn.execute(text("ALTER TABLE wallet_ledger ENABLE TRIGGER USER"))
    yield eng
    await eng.dispose()


def make_settings(**overrides: Any) -> Settings:
    values: dict[str, Any] = {
        "_env_file": None,
        "environment": "test",
        "database_url": os.environ.get("TEST_DATABASE_URL", ""),
        "secret_key": SECRET,
        "cors_origins": [ORIGIN],
        "trusted_hosts": ["testserver"],
        "log_json": False,
    }
    values.update(overrides)
    return Settings(**values)


@pytest.fixture
async def app(engine: AsyncEngine) -> AsyncIterator[FastAPI]:
    application = create_app(make_settings())
    async with application.router.lifespan_context(application):
        yield application


@pytest.fixture
async def client(app: FastAPI) -> AsyncIterator[httpx.AsyncClient]:
    transport = httpx.ASGITransport(app=app, raise_app_exceptions=False)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as http:
        yield http


def new_client(app: FastAPI) -> httpx.AsyncClient:
    """A second independent client (separate cookie jar), e.g. another user's browser."""
    return httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app, raise_app_exceptions=False),
        base_url="http://testserver",
    )


REGISTER = {"email": "ada@example.com", "username": "ada_l", "password": "a-long-enough-password"}
