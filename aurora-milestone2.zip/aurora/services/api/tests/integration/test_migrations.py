"""Alembic migrations and database-level guarantees, against a real PostgreSQL."""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError, IntegrityError
from sqlalchemy.ext.asyncio import AsyncEngine

from tests.integration.conftest import alembic

pytestmark = pytest.mark.integration

EXPECTED_TABLES = {
    "users",
    "sessions",
    "wallets",
    "games",
    "game_rounds",
    "wallet_ledger",
    "favorites",
    "achievements",
    "user_achievements",
    "audit_logs",
    "app_settings",
}


async def tables(engine: AsyncEngine) -> set[str]:
    async with engine.connect() as conn:
        rows = await conn.execute(
            text("SELECT tablename FROM pg_tables WHERE schemaname = 'public'")
        )
        return {r[0] for r in rows}


async def test_upgrade_head_creates_every_table_and_seed_data(engine: AsyncEngine) -> None:
    assert await tables(engine) >= EXPECTED_TABLES
    async with engine.connect() as conn:
        slugs = {r[0] for r in await conn.execute(text("SELECT slug FROM games"))}
        economy = (
            await conn.execute(text("SELECT value FROM app_settings WHERE key = 'economy'"))
        ).scalar_one()
        users = (await conn.execute(text("SELECT count(*) FROM users"))).scalar_one()
    assert slugs == {"dice", "mines", "plinko", "limbo", "coin-flip"}
    assert economy["initial_balance_units"] == 1_000_000
    assert users == 0  # reference data only: no seeded users, balances or fake stats


async def test_downgrade_then_upgrade_round_trips(migrated_database: str) -> None:
    down = alembic("downgrade", "base")
    assert down.returncode == 0, down.stderr
    up = alembic("upgrade", "head")
    assert up.returncode == 0, up.stderr


async def _wallet_with_round(engine: AsyncEngine) -> tuple[uuid.UUID, uuid.UUID, uuid.UUID]:
    user_id, wallet_id, round_id = uuid.uuid4(), uuid.uuid4(), uuid.uuid4()
    async with engine.begin() as conn:
        await conn.execute(
            text("INSERT INTO users (id, email, username) VALUES (:u, :e, :n)"),
            {"u": user_id, "e": f"{user_id}@example.com", "n": f"u{user_id.hex[:10]}"},
        )
        await conn.execute(
            text("INSERT INTO wallets (id, user_id, balance_units) VALUES (:w, :u, 1000)"),
            {"w": wallet_id, "u": user_id},
        )
        await conn.execute(
            text(
                "INSERT INTO game_rounds (id, user_id, game_id, stake_units, input_snapshot, "
                "idempotency_key) SELECT :r, :u, id, 100, '{}'::jsonb, 'k1' FROM games "
                "WHERE slug = 'dice'"
            ),
            {"r": round_id, "u": user_id},
        )
    return user_id, wallet_id, round_id


async def _ledger(
    engine: AsyncEngine, ids: tuple[uuid.UUID, uuid.UUID, uuid.UUID], kind: str, amount: int
) -> None:
    user_id, wallet_id, round_id = ids
    async with engine.begin() as conn:
        await conn.execute(
            text(
                "INSERT INTO wallet_ledger (wallet_id, user_id, round_id, entry_type, "
                "amount_units, balance_after_units) VALUES (:w, :u, :r, :t, :a, 900)"
            ),
            {"w": wallet_id, "u": user_id, "r": round_id, "t": kind, "a": amount},
        )


async def test_ledger_is_append_only(engine: AsyncEngine) -> None:
    ids = await _wallet_with_round(engine)
    await _ledger(engine, ids, "STAKE_DEBIT", -100)
    for statement in (
        "UPDATE wallet_ledger SET amount_units = -1",
        "DELETE FROM wallet_ledger",
        "TRUNCATE wallet_ledger",
    ):
        with pytest.raises(DBAPIError, match="append-only"):
            async with engine.begin() as conn:
                await conn.execute(text(statement))


async def test_a_round_is_debited_once_and_paid_once(engine: AsyncEngine) -> None:
    ids = await _wallet_with_round(engine)
    await _ledger(engine, ids, "STAKE_DEBIT", -100)
    await _ledger(engine, ids, "PAYOUT_CREDIT", 200)
    with pytest.raises(IntegrityError):
        await _ledger(engine, ids, "STAKE_DEBIT", -100)
    with pytest.raises(IntegrityError):
        await _ledger(engine, ids, "PAYOUT_CREDIT", 200)


async def test_ledger_sign_rules_and_wallet_nonnegative(engine: AsyncEngine) -> None:
    ids = await _wallet_with_round(engine)
    with pytest.raises(IntegrityError):  # a stake debit must be negative
        await _ledger(engine, ids, "STAKE_DEBIT", 100)
    with pytest.raises(IntegrityError):  # a payout must be positive
        await _ledger(engine, ids, "PAYOUT_CREDIT", -5)
    with pytest.raises(IntegrityError):  # balances can never go negative
        async with engine.begin() as conn:
            await conn.execute(text("UPDATE wallets SET balance_units = -1"))


async def test_round_idempotency_key_is_unique_per_user(engine: AsyncEngine) -> None:
    user_id, _, _ = await _wallet_with_round(engine)
    with pytest.raises(IntegrityError):
        async with engine.begin() as conn:
            await conn.execute(
                text(
                    "INSERT INTO game_rounds (user_id, game_id, stake_units, input_snapshot, "
                    "idempotency_key) SELECT :u, id, 100, '{}'::jsonb, 'k1' FROM games "
                    "WHERE slug = 'dice'"
                ),
                {"u": user_id},
            )


async def test_settled_round_must_have_consistent_net_and_timestamp(engine: AsyncEngine) -> None:
    _, _, round_id = await _wallet_with_round(engine)
    for sql in (
        "UPDATE game_rounds SET status='SETTLED', payout_units=200, net_result_units=100",
        "UPDATE game_rounds SET status='SETTLED', payout_units=200, net_result_units=5, "
        "settled_at=now()",
        "UPDATE game_rounds SET status='WON'",
    ):
        with pytest.raises(IntegrityError):
            async with engine.begin() as conn:
                await conn.execute(text(sql))
    async with engine.begin() as conn:  # the consistent form is accepted
        await conn.execute(
            text(
                "UPDATE game_rounds SET status='SETTLED', payout_units=200, "
                "net_result_units=100, settled_at=now() WHERE id = :r"
            ),
            {"r": round_id},
        )


async def test_username_uniqueness_is_case_insensitive_and_email_must_be_normalized(
    engine: AsyncEngine,
) -> None:
    async with engine.begin() as conn:
        await conn.execute(text("INSERT INTO users (email, username) VALUES ('a@x.io', 'Ada')"))
    with pytest.raises(IntegrityError):
        async with engine.begin() as conn:
            await conn.execute(text("INSERT INTO users (email, username) VALUES ('b@x.io', 'ADA')"))
    with pytest.raises(IntegrityError):
        async with engine.begin() as conn:
            await conn.execute(text("INSERT INTO users (email, username) VALUES ('C@x.io', 'c_c')"))
