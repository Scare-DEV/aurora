"""End-to-end auth behavior against a real PostgreSQL (migrated by Alembic)."""

from __future__ import annotations

import hashlib
from typing import Any

import httpx
import pytest
from fastapi import FastAPI
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine

from app.api.dependencies import AdminUser
from app.main import create_app
from tests.integration.conftest import ORIGIN, REGISTER, make_settings, new_client

pytestmark = pytest.mark.integration

COOKIE = "aurora_session"
P = "/api/v1"


async def register(client: httpx.AsyncClient, **overrides: Any) -> httpx.Response:
    return await client.post(f"{P}/auth/register", json={**REGISTER, **overrides})


def csrf_headers(response: httpx.Response) -> dict[str, str]:
    return {"X-CSRF-Token": response.json()["csrf_token"]}


async def scalar(engine: AsyncEngine, sql: str, **params: Any) -> Any:
    async with engine.connect() as conn:
        return (await conn.execute(text(sql), params)).scalar_one()


# ----------------------------------------------------------------- registration


async def test_register_creates_player_and_sets_secure_cookie(client: httpx.AsyncClient) -> None:
    r = await register(client)
    assert r.status_code == 201
    body = r.json()
    assert body["user"]["role"] == "player" and body["user"]["status"] == "active"
    assert body["user"]["email"] == "ada@example.com"
    assert body["csrf_token"] and body["expires_at"]
    assert "password" not in r.text and "password_hash" not in r.text

    cookie = r.headers["set-cookie"].lower()
    assert f"{COOKIE}=" in cookie
    assert "httponly" in cookie and "samesite=lax" in cookie and "path=/" in cookie


async def test_register_normalizes_email(client: httpx.AsyncClient) -> None:
    r = await register(client, email="  ADA@Example.com ")
    assert r.status_code == 201 and r.json()["user"]["email"] == "ada@example.com"


@pytest.mark.parametrize("field", ["role", "status", "id", "balance_units"])
async def test_cannot_self_assign_privileged_fields(
    client: httpx.AsyncClient, engine: AsyncEngine, field: str
) -> None:
    r = await register(client, **{field: "admin"})
    assert r.status_code == 422
    assert r.json()["code"] == "validation_error"
    assert await scalar(engine, "SELECT count(*) FROM users") == 0


async def test_validation_errors_do_not_echo_the_password(client: httpx.AsyncClient) -> None:
    r = await register(client, password="short-pw")
    assert r.status_code == 422
    assert "short-pw" not in r.text
    assert any(e["field"] == "password" for e in r.json()["field_errors"])


async def test_duplicate_email_or_username_gives_one_generic_conflict(
    client: httpx.AsyncClient, app: FastAPI
) -> None:
    assert (await register(client)).status_code == 201
    async with new_client(app) as other:
        same_email = await register(other, username="someone_else")
        same_username = await register(other, email="other@example.com", username="ADA_L")
    assert same_email.status_code == same_username.status_code == 409
    assert same_email.json()["code"] == same_username.json()["code"] == "account_unavailable"
    assert same_email.json()["message"] == same_username.json()["message"]


async def test_password_and_session_token_are_never_stored_in_plaintext(
    client: httpx.AsyncClient, engine: AsyncEngine
) -> None:
    await register(client)
    stored_hash = await scalar(engine, "SELECT password_hash FROM users")
    assert stored_hash.startswith("$argon2id$") and REGISTER["password"] not in stored_hash

    token = client.cookies.get(COOKIE)
    assert token
    stored_token = await scalar(engine, "SELECT token_hash FROM sessions")
    assert stored_token != token
    assert stored_token == hashlib.sha256(token.encode()).hexdigest()


# ------------------------------------------------------------------------ login


async def test_login_failures_are_indistinguishable(
    client: httpx.AsyncClient, app: FastAPI
) -> None:
    await register(client)
    async with new_client(app) as anon:
        wrong_pw = await anon.post(
            f"{P}/auth/login", json={"email": REGISTER["email"], "password": "not-the-password"}
        )
        no_user = await anon.post(
            f"{P}/auth/login", json={"email": "ghost@example.com", "password": "not-the-password"}
        )
    assert wrong_pw.status_code == no_user.status_code == 401
    a, b = wrong_pw.json(), no_user.json()
    assert (
        (a["code"], a["message"])
        == (b["code"], b["message"])
        == (
            "invalid_credentials",
            "Invalid email or password.",
        )
    )


async def test_login_success_sets_new_session_and_updates_last_login(
    client: httpx.AsyncClient, app: FastAPI, engine: AsyncEngine
) -> None:
    await register(client)
    async with new_client(app) as second:
        r = await second.post(
            f"{P}/auth/login",
            json={"email": "ADA@example.com", "password": REGISTER["password"]},
        )
        assert r.status_code == 200 and second.cookies.get(COOKIE)
    assert await scalar(engine, "SELECT count(*) FROM sessions") == 2
    assert await scalar(engine, "SELECT last_login_at IS NOT NULL FROM users") is True


async def test_login_is_rate_limited(engine: AsyncEngine) -> None:
    app = create_app(make_settings(login_rate_limit=3, login_rate_window_seconds=60))
    async with app.router.lifespan_context(app), new_client(app) as c:
        codes = [
            (
                await c.post(
                    f"{P}/auth/login", json={"email": "x@example.com", "password": "whatever"}
                )
            ).status_code
            for _ in range(5)
        ]
    assert codes == [401, 401, 401, 429, 429]


async def test_registration_can_be_disabled(engine: AsyncEngine) -> None:
    app = create_app(make_settings(registration_enabled=False))
    async with app.router.lifespan_context(app), new_client(app) as c:
        r = await register(c)
    assert r.status_code == 403 and r.json()["code"] == "registration_disabled"


# ------------------------------------------------------------------ sessions


async def test_me_requires_a_session(client: httpx.AsyncClient) -> None:
    r = await client.get(f"{P}/auth/me")
    assert r.status_code == 401 and r.json()["code"] == "unauthenticated"
    assert (await client.get(f"{P}/users/me")).status_code == 401


async def test_me_returns_current_user_and_csrf_token(client: httpx.AsyncClient) -> None:
    reg = await register(client)
    r = await client.get(f"{P}/auth/me")
    assert r.status_code == 200
    assert r.json()["user"]["username"] == "ada_l"
    assert r.json()["csrf_token"] == reg.json()["csrf_token"]


async def test_logout_requires_csrf_then_revokes_the_session(
    client: httpx.AsyncClient, app: FastAPI
) -> None:
    reg = await register(client)
    token = client.cookies.get(COOKIE)

    no_token = await client.post(f"{P}/auth/logout")
    assert no_token.status_code == 403 and no_token.json()["code"] == "csrf_failed"

    ok = await client.post(f"{P}/auth/logout", headers=csrf_headers(reg))
    assert ok.status_code == 204
    assert (await client.get(f"{P}/auth/me")).status_code == 401

    # Replaying the stolen/old cookie must fail: revocation is server-side.
    async with new_client(app) as replay:
        replay.cookies.set(COOKIE, token or "")
        assert (await replay.get(f"{P}/auth/me")).status_code == 401


async def test_expired_session_is_rejected(client: httpx.AsyncClient, engine: AsyncEngine) -> None:
    await register(client)
    async with engine.begin() as conn:
        await conn.execute(text("UPDATE sessions SET expires_at = now() - interval '1 minute'"))
    assert (await client.get(f"{P}/auth/me")).status_code == 401


async def test_idle_session_is_rejected(client: httpx.AsyncClient, engine: AsyncEngine) -> None:
    await register(client)
    async with engine.begin() as conn:
        await conn.execute(text("UPDATE sessions SET last_seen_at = now() - interval '2 days'"))
    assert (await client.get(f"{P}/auth/me")).status_code == 401


async def test_suspending_a_user_invalidates_existing_sessions_and_blocks_login(
    client: httpx.AsyncClient, app: FastAPI, engine: AsyncEngine
) -> None:
    await register(client)
    async with engine.begin() as conn:
        await conn.execute(text("UPDATE users SET status = 'suspended'"))
    assert (await client.get(f"{P}/auth/me")).status_code == 401
    async with new_client(app) as c:
        r = await c.post(
            f"{P}/auth/login",
            json={"email": REGISTER["email"], "password": REGISTER["password"]},
        )
    assert r.status_code == 403 and r.json()["code"] == "account_inactive"


# ----------------------------------------------------------------- CSRF/Origin


async def test_state_changing_request_without_csrf_token_is_rejected(
    client: httpx.AsyncClient,
) -> None:
    await register(client)
    r = await client.patch(f"{P}/users/me", json={"username": "new_name"})
    assert r.status_code == 403 and r.json()["code"] == "csrf_failed"


async def test_login_from_foreign_origin_is_rejected(client: httpx.AsyncClient) -> None:
    await register(client)
    creds = {"email": REGISTER["email"], "password": REGISTER["password"]}
    bad = await client.post(
        f"{P}/auth/login", json=creds, headers={"Origin": "http://evil.example"}
    )
    good = await client.post(f"{P}/auth/login", json=creds, headers={"Origin": ORIGIN})
    assert bad.status_code == 403 and bad.json()["code"] == "csrf_failed"
    assert good.status_code == 200


# ------------------------------------------------------------ profile + roles


async def test_profile_update_changes_username_only(
    client: httpx.AsyncClient, engine: AsyncEngine
) -> None:
    reg = await register(client)
    h = csrf_headers(reg)

    ok = await client.patch(f"{P}/users/me", json={"username": "ada_new"}, headers=h)
    assert ok.status_code == 200 and ok.json()["username"] == "ada_new"

    for payload in ({"role": "admin"}, {"status": "active"}, {"email": "x@y.io"}, {}):
        r = await client.patch(f"{P}/users/me", json=payload, headers=h)
        assert r.status_code == 422, payload
    assert await scalar(engine, "SELECT role FROM users") == "player"


async def test_username_conflict_on_update(client: httpx.AsyncClient, app: FastAPI) -> None:
    await register(client, username="taken_name")
    async with new_client(app) as other:
        reg = await register(other, email="b@example.com", username="other_name")
        r = await other.patch(
            f"{P}/users/me", json={"username": "TAKEN_NAME"}, headers=csrf_headers(reg)
        )
    assert r.status_code == 409 and r.json()["code"] == "account_unavailable"


async def test_users_only_ever_see_their_own_profile(
    client: httpx.AsyncClient, app: FastAPI
) -> None:
    await register(client)
    async with new_client(app) as other:
        await register(other, email="b@example.com", username="bob_b")
        mine = (await client.get(f"{P}/users/me")).json()
        theirs = (await other.get(f"{P}/users/me")).json()
    assert mine["id"] != theirs["id"]
    assert mine["username"] == "ada_l" and theirs["username"] == "bob_b"


async def test_admin_dependency_is_enforced_from_database_state(
    app: FastAPI, client: httpx.AsyncClient, engine: AsyncEngine
) -> None:
    @app.get("/_test/admin")
    async def admin_only(user: AdminUser) -> dict[str, str]:
        return {"admin": user.username}

    assert (await client.get("/_test/admin")).status_code == 401  # anonymous
    await register(client)
    denied = await client.get("/_test/admin")
    assert denied.status_code == 403 and denied.json()["code"] == "forbidden"

    async with engine.begin() as conn:
        await conn.execute(text("UPDATE users SET role = 'admin'"))
    assert (await client.get("/_test/admin")).json() == {"admin": "ada_l"}
