import httpx
from fastapi import FastAPI

from app import __version__
from app.core.config import Settings
from app.main import create_app
from tests.helpers import FakeRedis, FakeSession, use_fake_session


async def test_liveness_returns_ok_without_touching_dependencies(client: httpx.AsyncClient) -> None:
    response = await client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "service": "AURORA API", "version": __version__}


async def test_responses_carry_request_id_and_security_headers(client: httpx.AsyncClient) -> None:
    response = await client.get("/api/v1/health")
    assert len(response.headers["x-request-id"]) >= 8
    assert response.headers["x-content-type-options"] == "nosniff"
    assert response.headers["x-frame-options"] == "DENY"
    assert response.headers["referrer-policy"] == "no-referrer"
    assert response.headers["cache-control"] == "no-store"
    assert "default-src 'none'" in response.headers["content-security-policy"]


async def test_readiness_ok_with_redis_disabled(app: FastAPI, client: httpx.AsyncClient) -> None:
    use_fake_session(app, FakeSession())
    response = await client.get("/api/v1/health/ready")
    assert response.status_code == 200
    assert response.json() == {
        "status": "ok",
        "version": __version__,
        "checks": {"database": "ok", "redis": "disabled"},
    }


async def test_readiness_ok_with_redis(app: FastAPI, client: httpx.AsyncClient) -> None:
    use_fake_session(app, FakeSession())
    app.state.redis = FakeRedis()
    body = (await client.get("/api/v1/health/ready")).json()
    assert body["status"] == "ok"
    assert body["checks"] == {"database": "ok", "redis": "ok"}


async def test_readiness_is_503_when_database_fails_and_leaks_nothing(
    app: FastAPI, client: httpx.AsyncClient
) -> None:
    use_fake_session(app, FakeSession(RuntimeError("password=hunter2 host=db.internal")))
    response = await client.get("/api/v1/health/ready")
    assert response.status_code == 503
    body = response.json()
    assert body["status"] == "unavailable"
    assert body["checks"]["database"] == "error"
    assert "hunter2" not in response.text
    assert "db.internal" not in response.text


async def test_readiness_is_degraded_but_200_when_only_redis_fails(
    app: FastAPI, client: httpx.AsyncClient
) -> None:
    use_fake_session(app, FakeSession())
    app.state.redis = FakeRedis(ConnectionError("redis down"))
    response = await client.get("/api/v1/health/ready")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "degraded"
    assert body["checks"] == {"database": "ok", "redis": "error"}


async def test_openapi_documents_health_endpoints(client: httpx.AsyncClient) -> None:
    response = await client.get("/openapi.json")
    assert response.status_code == 200
    paths = response.json()["paths"]
    assert "/api/v1/health" in paths
    assert "/api/v1/health/ready" in paths


async def test_docs_can_be_disabled(settings: Settings) -> None:
    disabled = create_app(settings.model_copy(update={"docs_enabled": False}))
    transport = httpx.ASGITransport(app=disabled)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as http:
        for path in ("/docs", "/redoc", "/openapi.json"):
            assert (await http.get(path)).status_code == 404
