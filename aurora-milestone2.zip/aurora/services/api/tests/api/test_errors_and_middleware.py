from collections.abc import AsyncIterator

import httpx


def assert_error_shape(body: dict[str, object], code: str) -> None:
    assert body["code"] == code
    assert isinstance(body["message"], str)
    assert isinstance(body["request_id"], str)
    assert len(body["request_id"]) >= 8


# --- error model ------------------------------------------------------------


async def test_unknown_route_uses_error_schema(client: httpx.AsyncClient) -> None:
    response = await client.get("/api/v1/does-not-exist")
    assert response.status_code == 404
    body = response.json()
    assert_error_shape(body, "not_found")
    assert body["request_id"] == response.headers["x-request-id"]
    assert "field_errors" not in body


async def test_wrong_method_uses_error_schema(client: httpx.AsyncClient) -> None:
    response = await client.post("/api/v1/health")
    assert response.status_code == 405
    assert_error_shape(response.json(), "method_not_allowed")


async def test_validation_errors_list_fields_and_do_not_echo_input(
    client: httpx.AsyncClient,
) -> None:
    response = await client.post("/_test/echo", json={"name": 5, "amount": "abc"})
    assert response.status_code == 422
    body = response.json()
    assert_error_shape(body, "validation_error")
    assert {item["field"] for item in body["field_errors"]} == {"name", "amount"}
    assert "abc" not in response.text


async def test_missing_body_fields_are_reported(client: httpx.AsyncClient) -> None:
    response = await client.post("/_test/echo", json={})
    assert response.status_code == 422
    assert {item["field"] for item in response.json()["field_errors"]} == {"name", "amount"}


async def test_app_errors_map_to_their_status_and_code(client: httpx.AsyncClient) -> None:
    response = await client.get("/_test/forbidden")
    assert response.status_code == 403
    assert_error_shape(response.json(), "forbidden")


async def test_unexpected_errors_return_generic_500_without_internals(
    client: httpx.AsyncClient,
) -> None:
    response = await client.get("/_test/boom")
    assert response.status_code == 500
    body = response.json()
    assert_error_shape(body, "internal_error")
    assert "secret internal detail" not in response.text
    assert "RuntimeError" not in response.text
    assert "Traceback" not in response.text
    assert body["request_id"] == response.headers["x-request-id"]


# --- request IDs ------------------------------------------------------------


async def test_valid_inbound_request_id_is_echoed(client: httpx.AsyncClient) -> None:
    response = await client.get("/api/v1/nope", headers={"X-Request-ID": "trace-abc-12345"})
    assert response.headers["x-request-id"] == "trace-abc-12345"
    assert response.json()["request_id"] == "trace-abc-12345"


async def test_unsafe_inbound_request_id_is_replaced(client: httpx.AsyncClient) -> None:
    response = await client.get("/api/v1/health", headers={"X-Request-ID": "bad id with spaces!!"})
    assert response.headers["x-request-id"] != "bad id with spaces!!"
    assert len(response.headers["x-request-id"]) == 32


# --- trusted hosts and CORS -------------------------------------------------


async def test_untrusted_host_is_rejected(client: httpx.AsyncClient) -> None:
    response = await client.get("/api/v1/health", headers={"Host": "evil.example"})
    assert response.status_code == 400


async def test_cors_allows_listed_origin_with_credentials(client: httpx.AsyncClient) -> None:
    response = await client.options(
        "/api/v1/health",
        headers={
            "Origin": "http://localhost:3000",
            "Access-Control-Request-Method": "GET",
            "Access-Control-Request-Headers": "content-type",
        },
    )
    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "http://localhost:3000"
    assert response.headers["access-control-allow-credentials"] == "true"


async def test_cors_does_not_allow_unlisted_origin(client: httpx.AsyncClient) -> None:
    preflight = await client.options(
        "/api/v1/health",
        headers={"Origin": "http://evil.example", "Access-Control-Request-Method": "GET"},
    )
    assert "access-control-allow-origin" not in preflight.headers
    simple = await client.get("/api/v1/health", headers={"Origin": "http://evil.example"})
    assert "access-control-allow-origin" not in simple.headers


# --- request body limit (configured as 2048 bytes in the test settings) ------


async def test_body_within_limit_is_accepted(client: httpx.AsyncClient) -> None:
    response = await client.post("/_test/echo", json={"name": "ok", "amount": 1})
    assert response.status_code == 200
    assert response.json() == {"name": "ok", "amount": 1}


async def test_declared_oversized_body_gets_413(client: httpx.AsyncClient) -> None:
    response = await client.post(
        "/_test/echo", content=b"x" * 5000, headers={"Content-Type": "application/json"}
    )
    assert response.status_code == 413
    assert_error_shape(response.json(), "payload_too_large")


async def test_streamed_oversized_body_without_content_length_gets_413(
    client: httpx.AsyncClient,
) -> None:
    async def chunks() -> AsyncIterator[bytes]:
        for _ in range(10):
            yield b"x" * 500

    response = await client.post(
        "/_test/echo", content=chunks(), headers={"Content-Type": "application/json"}
    )
    assert response.status_code == 413
    assert_error_shape(response.json(), "payload_too_large")
