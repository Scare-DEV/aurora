import logging
from collections.abc import AsyncIterator, Iterator
from typing import Any

import httpx
import pytest
from fastapi import FastAPI
from pydantic import BaseModel

from app.core.config import Settings
from app.core.errors import ForbiddenError
from app.main import create_app

DB_URL = "postgresql+asyncpg://user:pass@localhost:5432/db"


class EchoPayload(BaseModel):
    name: str
    amount: int


@pytest.fixture(autouse=True)
def _preserve_logging() -> Iterator[None]:
    """create_app() reconfigures the root logger; restore it after each test."""
    root = logging.getLogger()
    handlers, level = list(root.handlers), root.level
    yield
    root.handlers[:] = handlers
    root.setLevel(level)


@pytest.fixture
def settings() -> Settings:
    return Settings(  # type: ignore[call-arg]
        _env_file=None,
        environment="test",
        database_url=DB_URL,
        secret_key="Zk3vQ9rT7pLx2WnB5dHs8YcF1mJg6AeU4oIy0Rt",
        cors_origins=["http://localhost:3000"],
        trusted_hosts=["testserver", "localhost"],
        max_request_bytes=2048,
        log_json=False,
    )


@pytest.fixture
def app(settings: Settings) -> FastAPI:
    application = create_app(settings)

    # Test-only routes exercising validation, domain errors and unexpected failures.
    @application.post("/_test/echo")
    async def echo(payload: EchoPayload) -> dict[str, Any]:
        return payload.model_dump()

    @application.get("/_test/forbidden")
    async def forbidden() -> None:
        raise ForbiddenError()

    @application.get("/_test/boom")
    async def boom() -> None:
        raise RuntimeError("secret internal detail")

    return application


@pytest.fixture
async def client(app: FastAPI) -> AsyncIterator[httpx.AsyncClient]:
    # raise_app_exceptions=False so unhandled errors surface as real HTTP 500 responses.
    transport = httpx.ASGITransport(app=app, raise_app_exceptions=False)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as http:
        yield http
