"""Test doubles shared by API tests (kept out of conftest.py so they import once)."""

from typing import Any

from fastapi import FastAPI

from app.db.session import get_session


class FakeSession:
    """Stands in for AsyncSession so readiness logic is tested without a database."""

    def __init__(self, error: Exception | None = None) -> None:
        self.error = error

    async def execute(self, *_args: Any, **_kwargs: Any) -> None:
        if self.error is not None:
            raise self.error


class FakeRedis:
    def __init__(self, error: Exception | None = None) -> None:
        self.error = error

    async def ping(self) -> bool:
        if self.error is not None:
            raise self.error
        return True


def use_fake_session(app: FastAPI, session: FakeSession) -> None:
    app.dependency_overrides[get_session] = lambda: session
