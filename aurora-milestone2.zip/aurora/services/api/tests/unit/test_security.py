"""Password hashing, session tokens and CSRF tokens (needs argon2-cffi + anyio)."""

import re

from app.core.security import (
    csrf_token_for,
    csrf_token_valid,
    hash_password,
    hash_password_async,
    hash_token,
    new_session_token,
    password_needs_rehash,
    verify_password,
    verify_password_async,
)

SECRET = "Zk3vQ9rT7pLx2WnB5dHs8YcF1mJg6AeU4oIy0Rt"


def test_password_is_hashed_with_argon2id_and_salted() -> None:
    first, second = hash_password("correct horse battery"), hash_password("correct horse battery")
    assert first.startswith("$argon2id$")
    assert first != second  # unique salt per hash
    assert "correct horse" not in first


def test_verify_password_accepts_only_the_right_password() -> None:
    hashed = hash_password("correct horse battery")
    assert verify_password(hashed, "correct horse battery") is True
    assert verify_password(hashed, "wrong") is False
    assert verify_password("not-a-hash", "anything") is False


def test_fresh_hash_does_not_need_rehash() -> None:
    assert password_needs_rehash(hash_password("x" * 12)) is False
    assert password_needs_rehash("garbage") is True


async def test_async_helpers_and_unknown_account_path() -> None:
    hashed = await hash_password_async("correct horse battery")
    assert await verify_password_async(hashed, "correct horse battery") is True
    assert await verify_password_async(hashed, "nope") is False
    # Unknown account (no stored hash): must be False, after doing comparable work.
    assert await verify_password_async(None, "anything") is False


def test_session_tokens_are_unique_and_long() -> None:
    tokens = {new_session_token() for _ in range(200)}
    assert len(tokens) == 200
    assert all(len(t) >= 43 for t in tokens)  # 256 bits, urlsafe base64


def test_token_hash_is_sha256_hex_and_not_the_token() -> None:
    token = new_session_token()
    digest = hash_token(token)
    assert re.fullmatch(r"[0-9a-f]{64}", digest)
    assert token not in digest
    assert hash_token(token) == digest


def test_csrf_token_is_bound_to_session_and_secret() -> None:
    token = csrf_token_for("session-a", SECRET)
    assert csrf_token_valid(token, "session-a", SECRET) is True
    assert csrf_token_valid(token, "session-b", SECRET) is False  # other session
    assert csrf_token_valid(token, "session-a", SECRET + "x") is False  # other secret
    assert csrf_token_valid(None, "session-a", SECRET) is False
    assert csrf_token_valid("", "session-a", SECRET) is False
    assert csrf_token_valid(token[:-1], "session-a", SECRET) is False
