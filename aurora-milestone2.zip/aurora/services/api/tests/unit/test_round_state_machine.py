"""Round state machine: only explicitly allowed transitions (needs sqlalchemy)."""

import pytest

from app.models.game_round import ALLOWED_TRANSITIONS, RoundStatus, can_transition


def test_every_status_has_an_entry() -> None:
    assert set(ALLOWED_TRANSITIONS) == set(RoundStatus)


@pytest.mark.parametrize(
    ("current", "target"),
    [
        (RoundStatus.CREATED, RoundStatus.SETTLED),
        (RoundStatus.CREATED, RoundStatus.CANCELLED),
        (RoundStatus.CREATED, RoundStatus.IN_PROGRESS),
        (RoundStatus.IN_PROGRESS, RoundStatus.SETTLED),
        (RoundStatus.IN_PROGRESS, RoundStatus.CANCELLED),
    ],
)
def test_allowed(current: RoundStatus, target: RoundStatus) -> None:
    assert can_transition(current, target)


@pytest.mark.parametrize("terminal", [RoundStatus.SETTLED, RoundStatus.CANCELLED])
def test_terminal_states_are_final(terminal: RoundStatus) -> None:
    assert not any(can_transition(terminal, target) for target in RoundStatus)


def test_no_going_backwards() -> None:
    assert not can_transition(RoundStatus.IN_PROGRESS, RoundStatus.CREATED)
    assert not can_transition(RoundStatus.CREATED, RoundStatus.CREATED)
