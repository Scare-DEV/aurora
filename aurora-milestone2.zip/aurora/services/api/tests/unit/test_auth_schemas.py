"""Request validation for auth DTOs (needs pydantic + email-validator)."""

import pytest
from pydantic import ValidationError

from app.schemas.auth import LoginRequest, RegisterRequest, UpdateProfileRequest


def make(**overrides: object) -> RegisterRequest:
    data: dict[str, object] = {
        "email": "  Ada@Example.COM ",
        "username": "ada_l",
        "password": "a-long-enough-password",
    }
    data.update(overrides)
    return RegisterRequest(**data)  # type: ignore[arg-type]


def test_email_is_trimmed_and_lowercased() -> None:
    assert str(make().email) == "ada@example.com"
    assert str(LoginRequest(email="X@Y.io", password="p").email) == "x@y.io"


@pytest.mark.parametrize("username", ["ab", "a" * 25, "has space", "semi;colon", "ünïcode", ""])
def test_bad_usernames_rejected(username: str) -> None:
    with pytest.raises(ValidationError):
        make(username=username)


@pytest.mark.parametrize("password", ["short", "x" * 9, "x" * 129])
def test_password_length_policy(password: str) -> None:
    with pytest.raises(ValidationError):
        make(password=password)


def test_password_must_not_equal_identity() -> None:
    with pytest.raises(ValidationError):
        make(username="longusername", password="LongUserName")


@pytest.mark.parametrize("field", ["role", "status", "id", "balance_units", "is_admin"])
def test_privileged_fields_are_rejected_not_ignored(field: str) -> None:
    with pytest.raises(ValidationError) as info:
        make(**{field: "admin"})
    assert any(err["type"] == "extra_forbidden" for err in info.value.errors())


def test_invalid_email_rejected() -> None:
    with pytest.raises(ValidationError):
        make(email="not-an-email")


def test_profile_update_requires_a_field_and_forbids_extras() -> None:
    assert UpdateProfileRequest(username="new_name").username == "new_name"
    with pytest.raises(ValidationError):
        UpdateProfileRequest()
    with pytest.raises(ValidationError):
        UpdateProfileRequest(username="ok_name", role="admin")  # type: ignore[call-arg]
