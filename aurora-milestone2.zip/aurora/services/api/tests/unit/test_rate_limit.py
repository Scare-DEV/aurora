"""In-memory rate limiter behavior (the Redis path is exercised in integration tests)."""

import pytest

from app.core import rate_limit
from app.core.rate_limit import RateLimiter, hashed_key


async def test_allows_up_to_limit_then_blocks() -> None:
    limiter = RateLimiter(None)
    results = [await limiter.hit("login", "1.2.3.4", 3, 60) for _ in range(5)]
    assert [r.allowed for r in results] == [True, True, True, False, False]
    assert results[-1].retry_after_seconds >= 1


async def test_scopes_and_identifiers_are_independent() -> None:
    limiter = RateLimiter(None)
    for _ in range(2):
        await limiter.hit("login", "a", 2, 60)
    assert (await limiter.hit("login", "a", 2, 60)).allowed is False
    assert (await limiter.hit("login", "b", 2, 60)).allowed is True
    assert (await limiter.hit("register", "a", 2, 60)).allowed is True


async def test_window_expires(monkeypatch: pytest.MonkeyPatch) -> None:
    now = [1000.0]
    monkeypatch.setattr(rate_limit.time, "monotonic", lambda: now[0])
    limiter = RateLimiter(None)
    assert (await limiter.hit("s", "x", 1, 10)).allowed is True
    assert (await limiter.hit("s", "x", 1, 10)).allowed is False
    now[0] += 11
    assert (await limiter.hit("s", "x", 1, 10)).allowed is True


def test_keys_are_hashed_not_raw() -> None:
    key = hashed_key("person@example.com")
    assert "person" not in key and "@" not in key
    assert hashed_key("a", "b") != hashed_key("ab")


async def test_redis_failure_falls_back_to_memory() -> None:
    class BrokenRedis:
        def pipeline(self) -> object:
            raise ConnectionError("redis down")

    limiter = RateLimiter(BrokenRedis())  # type: ignore[arg-type]
    assert (await limiter.hit("s", "x", 1, 10)).allowed is True
    assert (await limiter.hit("s", "x", 1, 10)).allowed is False
