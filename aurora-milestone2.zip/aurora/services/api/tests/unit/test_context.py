import re

import pytest

from app.core.context import new_request_id, sanitize_request_id


def test_valid_inbound_request_id_is_kept() -> None:
    assert sanitize_request_id("abc12345-DEF_678") == "abc12345-DEF_678"


@pytest.mark.parametrize(
    "candidate",
    [
        None,
        "",
        "short",  # fewer than 8 characters
        "x" * 65,  # more than 64 characters
        "has spaces in it",
        "line\nbreak-injection",
        "carriage\rreturn-here",
        "semi;colon;chars!",
        "unicode-é-chars-here",
    ],
)
def test_unsafe_inbound_request_id_is_replaced(candidate: str | None) -> None:
    result = sanitize_request_id(candidate)
    assert result != candidate
    assert re.fullmatch(r"[0-9a-f]{32}", result)


def test_boundary_lengths_are_accepted() -> None:
    assert sanitize_request_id("a" * 8) == "a" * 8
    assert sanitize_request_id("a" * 64) == "a" * 64


def test_new_request_ids_are_unique_hex() -> None:
    ids = {new_request_id() for _ in range(200)}
    assert len(ids) == 200
    assert all(re.fullmatch(r"[0-9a-f]{32}", value) for value in ids)
