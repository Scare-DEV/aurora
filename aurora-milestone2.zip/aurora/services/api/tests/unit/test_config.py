from typing import Any

import pytest
from pydantic import ValidationError

from app.core.config import Settings

VALID_URL = "postgresql+asyncpg://user:pass@localhost:5432/db"
STRONG_SECRET = "Zk3vQ9rT7pLx2WnB5dHs8YcF1mJg6AeU4oIy0Rt"


def make(**overrides: Any) -> Settings:
    values: dict[str, Any] = {"database_url": VALID_URL, "secret_key": STRONG_SECRET}
    values.update(overrides)
    return Settings(_env_file=None, **values)  # type: ignore[call-arg]


def test_defaults_are_safe() -> None:
    settings = make()
    assert settings.environment == "development"
    assert settings.cors_origins == ["http://localhost:3000"]
    assert settings.redis_url is None
    assert settings.max_request_bytes == 1_048_576


@pytest.mark.parametrize(
    "url",
    [
        "sqlite+aiosqlite:///./aurora.db",
        "postgresql://user:pass@localhost/db",  # sync driver scheme
        "mysql+aiomysql://user:pass@localhost/db",
        "",
    ],
)
def test_database_url_must_be_postgres_asyncpg(url: str) -> None:
    with pytest.raises(ValidationError):
        make(database_url=url)


def test_database_url_and_secret_key_are_required(monkeypatch: pytest.MonkeyPatch) -> None:
    for name in ("DATABASE_URL", "SECRET_KEY"):
        monkeypatch.delenv(name, raising=False)
    with pytest.raises(ValidationError) as excinfo:
        Settings(_env_file=None)  # type: ignore[call-arg]
    missing = {error["loc"][0] for error in excinfo.value.errors()}
    assert {"database_url", "secret_key"} <= missing


def test_cors_wildcards_are_rejected() -> None:
    with pytest.raises(ValidationError):
        make(cors_origins=["*"])
    with pytest.raises(ValidationError):
        make(cors_origins=["https://*.example.com"])


def test_csv_environment_values_are_parsed(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CORS_ORIGINS", "http://a.test, http://b.test ,")
    monkeypatch.setenv("TRUSTED_HOSTS", "localhost,api")
    settings = make()
    assert settings.cors_origins == ["http://a.test", "http://b.test"]
    assert settings.trusted_hosts == ["localhost", "api"]


def test_empty_trusted_hosts_rejected() -> None:
    with pytest.raises(ValidationError):
        make(trusted_hosts=[])


def test_blank_redis_url_means_disabled() -> None:
    assert make(redis_url="").redis_url is None
    assert make(redis_url="   ").redis_url is None
    assert make(redis_url="redis://localhost:6379/0").redis_url == "redis://localhost:6379/0"


@pytest.mark.parametrize("value", [0, 1023, 16_777_217])
def test_request_size_limit_bounds(value: int) -> None:
    with pytest.raises(ValidationError):
        make(max_request_bytes=value)


@pytest.mark.parametrize(
    "secret",
    ["short", "dev-only-change-me-dev-only-change-me-0123456789", "x" * 10],
)
def test_production_rejects_weak_or_placeholder_secrets(secret: str) -> None:
    with pytest.raises(ValidationError):
        make(environment="production", secret_key=secret)


def test_production_accepts_strong_secret() -> None:
    assert make(environment="production").environment == "production"


def test_development_accepts_placeholder_secret() -> None:
    assert make(secret_key="dev-only-change-me").environment == "development"


def test_secret_key_is_not_exposed_in_repr() -> None:
    settings = make()
    assert STRONG_SECRET not in repr(settings)
    assert STRONG_SECRET not in str(settings.model_dump())
