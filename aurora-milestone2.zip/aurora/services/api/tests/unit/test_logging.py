import json
import logging
import sys
from collections.abc import Iterator
from typing import Any

import pytest

from app.core.context import request_id_ctx
from app.core.logging import (
    REDACTED,
    JsonFormatter,
    TextFormatter,
    configure_logging,
    redact,
)


def _record(message: str = "hello", **extra: Any) -> logging.LogRecord:
    logger = logging.getLogger("test.logger")
    return logger.makeRecord(
        "test.logger", logging.INFO, __file__, 10, message, (), None, extra=extra or None
    )


@pytest.fixture
def request_id() -> Iterator[str]:
    token = request_id_ctx.set("req-1234567890")
    try:
        yield "req-1234567890"
    finally:
        request_id_ctx.reset(token)


def test_json_output_is_valid_with_core_fields() -> None:
    payload = json.loads(JsonFormatter().format(_record("hello world")))
    assert payload["message"] == "hello world"
    assert payload["level"] == "INFO"
    assert payload["logger"] == "test.logger"
    assert payload["ts"].endswith("+00:00")  # timestamps are UTC
    assert "request_id" not in payload


def test_json_output_includes_request_id_when_set(request_id: str) -> None:
    payload = json.loads(JsonFormatter().format(_record()))
    assert payload["request_id"] == request_id


def test_extras_are_included_and_sensitive_keys_redacted() -> None:
    record = _record(
        "login",
        path="/api/v1/auth/login",
        password="hunter2",
        refresh_token="abc",
        headers={"Authorization": "Bearer xyz", "accept": "application/json"},
    )
    output = JsonFormatter().format(record)
    payload = json.loads(output)
    assert payload["path"] == "/api/v1/auth/login"
    assert payload["password"] == REDACTED
    assert payload["refresh_token"] == REDACTED
    assert payload["headers"]["Authorization"] == REDACTED
    assert payload["headers"]["accept"] == "application/json"
    for secret in ("hunter2", "Bearer xyz"):
        assert secret not in output


def test_non_serialisable_extras_do_not_crash_formatting() -> None:
    payload = json.loads(JsonFormatter().format(_record(obj=object())))
    assert isinstance(payload["obj"], str)


def test_exception_info_is_included() -> None:
    try:
        raise ValueError("boom")
    except ValueError:
        record = logging.getLogger("test.logger").makeRecord(
            "test.logger", logging.ERROR, __file__, 10, "failed", (), sys.exc_info()
        )
    payload = json.loads(JsonFormatter().format(record))
    assert "ValueError: boom" in payload["exception"]


def test_redact_handles_nesting_and_lists() -> None:
    data = {
        "user": {"name": "bob", "Password": "x", "sessions": [{"session_token": "t", "ip": "1"}]},
        "ok": 1,
    }
    result = redact(data)
    assert result["user"]["name"] == "bob"
    assert result["user"]["Password"] == REDACTED
    assert result["user"]["sessions"][0]["session_token"] == REDACTED
    assert result["user"]["sessions"][0]["ip"] == "1"
    assert result["ok"] == 1
    # input is not mutated
    assert data["user"]["Password"] == "x"


def test_text_formatter_shows_request_id_or_dash(request_id: str) -> None:
    assert "[req-1234567890]" in TextFormatter().format(_record("hi"))
    request_id_ctx.set(None)
    assert "[-]" in TextFormatter().format(_record("hi"))


def test_configure_logging_is_idempotent_and_replaces_handlers() -> None:
    root = logging.getLogger()
    saved_handlers, saved_level = list(root.handlers), root.level
    try:
        configure_logging("WARNING", json_logs=True)
        configure_logging("DEBUG", json_logs=False)
        assert len(root.handlers) == 1
        assert isinstance(root.handlers[0].formatter, TextFormatter)
        assert root.level == logging.DEBUG
        assert logging.getLogger("uvicorn.access").propagate is False
    finally:
        root.handlers[:] = saved_handlers
        root.setLevel(saved_level)
