# API (Milestone 2 endpoints)

Base path `/api/v1`. Interactive docs at `/docs` when `DOCS_ENABLED`. Errors always use
`{"code", "message", "request_id", "field_errors"?}`. State-changing authenticated requests need
`X-CSRF-Token` (see [security.md](security.md)).

| Method & path | Auth | Request | Success | Errors |
| --- | --- | --- | --- | --- |
| `GET /health` | none | | 200 liveness | |
| `GET /health/ready` | none | | 200 ok/degraded | 503 database down |
| `POST /auth/register` | none | `{email, username, password}` | 201 `SessionInfo` + cookie | 403 `registration_disabled`, 409 `account_unavailable`, 422, 429 |
| `POST /auth/login` | none | `{email, password}` | 200 `SessionInfo` + cookie | 401 `invalid_credentials`, 403 `account_inactive`, 422, 429 |
| `POST /auth/logout` | session + CSRF | | 204, cookie cleared (idempotent) | 403 `csrf_failed` |
| `GET /auth/me` | session | | 200 `SessionInfo` | 401 |
| `GET /users/me` | session | | 200 `UserPublic` | 401 |
| `PATCH /users/me` | session + CSRF | `{username}` (only field) | 200 `UserPublic` | 401, 403, 409 `account_unavailable`, 422 |

`SessionInfo = {user: UserPublic, csrf_token, expires_at}`;
`UserPublic = {id, email, username, role, status, created_at, last_login_at}`.
Not implemented by design: `POST /auth/refresh` (no refresh tokens; sessions are server-side).
Wallet, games, favorites, leaderboard, achievements and admin endpoints arrive in later milestones.
