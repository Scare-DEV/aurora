# Security (Milestone 2: authentication and sessions)

AURORA uses **server-side sessions in PostgreSQL**, delivered in an HttpOnly cookie. There are no
JWTs, no refresh tokens and nothing in `localStorage`. (`POST /auth/refresh` is therefore
intentionally not implemented; the spec allows it only "if refresh tokens are implemented".)

## Credentials and sessions

| Topic | Decision |
| --- | --- |
| Password hashing | Argon2id via `argon2-cffi` defaults (RFC 9106 low-memory profile), run in a worker thread so it never blocks the event loop. Hashes are upgraded on login if parameters change. |
| Password policy | 10-128 characters; must not equal the username or email. No composition rules (they reduce entropy in practice). |
| Session token | 256 random bits from `secrets`. Only its SHA-256 is stored (`sessions.token_hash`), so a database leak does not yield usable cookies. |
| Cookie | `aurora_session`; `HttpOnly`; `SameSite=Lax`; `Path=/`; `Secure` when `ENVIRONMENT=production` (override with `COOKIE_SECURE`). |
| Lifetime | Absolute 7 days (`SESSION_TTL_SECONDS`) **and** 24 h idle (`SESSION_IDLE_SECONDS`). `last_seen_at` is refreshed at most once a minute. |
| Invalidation | Logout sets `revoked_at`. Suspending/deleting a user takes effect on the next request because the user's status is checked on every request. Replaying an old cookie fails. |
| Account enumeration | Login returns one `invalid_credentials` response for unknown email and wrong password, and an unknown email still performs one Argon2 verification (timing). Registration conflicts (email or username) return one `account_unavailable` message. A suspended account is only revealed after the correct password. |
| Roles | Assigned only server-side (`player` on registration). Request schemas use `extra="forbid"`, so `role`/`status` in a body is a 422, not silently ignored. Admin routes use the `AdminUser` dependency, which reads the role from the database on every request. |

## CSRF

Cookie-authenticated state-changing requests (`POST/PUT/PATCH/DELETE`) must satisfy all of:

1. `SameSite=Lax` cookie (not attached to cross-site unsafe requests by the browser).
2. If an `Origin` header is present it must be in `CORS_ORIGINS` (exact match, no wildcards).
3. `X-CSRF-Token` must equal `HMAC-SHA256(SECRET_KEY, "csrf:" + session token)`, compared in
   constant time. The token is returned in the JSON body of `register`, `login` and `GET /auth/me`;
   the web app keeps it in memory and re-fetches it from `/auth/me` on page load. It is
   deliberately **not** put in a readable cookie, so it also works when web and API are on
   different domains.

`/auth/login` and `/auth/register` are exempt from (3) (they create the session) but not from (1)
and (2). Implemented in `app/core/csrf.py`; tests in `tests/security/` and `tests/integration/`.

## Rate limiting

Fixed window, keyed by SHA-256 of the identifier (raw IPs/emails never appear in Redis keys).
Login: 10 attempts / 5 min **per IP and per account**. Registration: 5 / hour per IP. Redis is used
when configured; otherwise an in-process fallback (per worker, development only). A Redis outage
degrades to the in-process limiter rather than disabling limits or failing logins. The client IP
is the direct peer address; `X-Forwarded-For` is not trusted unless uvicorn is told which proxies
to trust.

## Other controls (from Milestone 1)

Strict CORS allowlist, trusted-host list, request-size limit, security headers, generic 500
errors with a request ID (no stack traces), secrets only from the environment (production refuses
placeholder/short `SECRET_KEY`).

## Known limitations

- No email verification or password reset yet (would need an email provider).
- No per-session listing or "sign out everywhere" endpoint yet.
- Argon2 cost is the library default; tune for your hardware before production.
- Content-Security-Policy for the web app is scheduled for Milestone 8.
