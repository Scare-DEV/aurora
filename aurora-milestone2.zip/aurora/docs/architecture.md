# Architecture (Milestone 1)

AURORA is a monorepo with an API-first design. The browser talks to the FastAPI service over a
versioned REST API (`/api/v1`); PostgreSQL is the only source of truth. Redis is optional and
used only for rate limiting, caching and short-lived coordination.

```
Browser ──► Next.js (apps/web)  ──fetch (credentials: include)──►  FastAPI (services/api)
                                                                      │        │
                                                                      ▼        ▼
                                                                 PostgreSQL   Redis (optional)
```

## Backend structure

| Path | Responsibility |
| --- | --- |
| `app/main.py` | Application factory (`create_app`) and lifespan (engine, session factory, Redis) |
| `app/core/config.py` | Environment settings, validated at startup |
| `app/core/context.py` | Request-ID context variable and sanitiser (stdlib only) |
| `app/core/logging.py` | JSON/text logging with request IDs and key-based redaction (stdlib only) |
| `app/core/errors.py` | Error schema, `AppError` hierarchy, exception handlers |
| `app/core/middleware.py` | Request context/access log/security headers; body-size limit |
| `app/db/` | Declarative base (named constraints), async engine and sessions, Redis client |
| `app/api/` | Dependencies and versioned routers; endpoints stay thin, logic goes in `services/` |

Business logic will live in `app/services/` and `app/game_engines/` (milestones 2+), never in route
handlers or React components.

### Middleware order (outermost first)

`RequestContext` → `TrustedHost` → `CORS` → `BodySizeLimit` → routes.

Request IDs are assigned first so every response, including rejections from the layers below, is
traceable. Inbound `X-Request-ID` values are accepted only if they match `[A-Za-z0-9_-]{8,64}`
(prevents log injection).

### Error model

Every error body is `{code, message, request_id, field_errors?}`.

- Validation errors (422) list field names and messages only. Submitted values are never echoed.
- Unhandled exceptions return a generic 500 and are logged with the stack trace server-side.
- `ErrorResponse` and the `AppError` subclasses map to the status codes in the spec
  (400, 401, 403, 404, 409, 413, 422, 429, 500).
- Known exception: `TrustedHostMiddleware` rejects bad `Host` headers with Starlette's plain-text
  400, which is not the JSON error schema.

### Health endpoints

| Endpoint | Behaviour |
| --- | --- |
| `GET /api/v1/health` | Liveness. 200 while the process runs; checks nothing else. |
| `GET /api/v1/health/ready` | `SELECT 1` against PostgreSQL and `PING` against Redis (if configured), each with a 3 s timeout. DB down → **503** `unavailable`. Redis down → 200 `degraded`. Reports component states only, never exception messages. |

The 503 readiness response is outside the spec's status-code list; it is the conventional signal for
orchestrators and is documented in OpenAPI.

### Database sessions

`get_session` yields one `AsyncSession` per request. **Nothing commits implicitly**; services commit
explicitly, and an uncommitted session rolls back on close. This is the foundation for the
single-transaction wallet/round operations in milestone 3. Connections force `timezone=UTC`.

## Frontend structure

Next.js App Router, strict TypeScript. Route group `(public)` uses `AppShell` (header, collapsible
sidebar, footer). Server state goes through TanStack Query; API responses are validated with Zod
at the boundary (`lib/api/client.ts`), so transport failures, error statuses and schema mismatches
are three distinct, visible error types, and no result is ever fabricated.

Design tokens are CSS custom properties in `globals.css`, exposed to Tailwind via `@theme inline`.
Navigation items for pages that don't exist yet render as non-interactive text, never as links or
buttons that do nothing.

## Decisions and deviations from the spec

| Item | Decision |
| --- | --- |
| Alembic | Not scaffolded in M1 (no models yet); added in M2 with the first migration so it can be tested against real PostgreSQL. |
| Dependencies | `framer-motion`, `react-hook-form` and `@hookform/resolvers` are not installed yet; they are added in the milestone that first uses them. |
| Top nav | Only items that work are shown (brand, Responsible play, sidebar toggle). Search, notifications, profile, balance, login/register arrive with the features behind them. |
| Auth architecture | Not yet chosen in code. Plan for M2: server-side sessions in HttpOnly/Secure/SameSite cookies with CSRF tokens (`X-CSRF-Token` is already in the CORS allow-list). |
| Lockfiles | Not generated (registries unreachable in the authoring sandbox). |
| CSP | Deferred to milestone 8 for the web app (needs nonces). API sets a strict CSP on non-docs paths. |
