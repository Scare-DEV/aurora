# Development

## Configuration

| Variable | Used by | Notes |
| --- | --- | --- |
| `DATABASE_URL` | API | Required. Must start with `postgresql+asyncpg://` (SQLite is rejected). |
| `SECRET_KEY` | API | Required. In `production`, must be ≥ 32 chars and not look like a placeholder. |
| `ENVIRONMENT` | API | `development` \| `test` \| `production` |
| `REDIS_URL` | API | Optional. Empty = Redis disabled (readiness reports `disabled`). |
| `CORS_ORIGINS` | API | Comma-separated explicit allowlist. Wildcards rejected. |
| `TRUSTED_HOSTS` | API | Accepted `Host` headers. Include `api` for Compose. |
| `MAX_REQUEST_BYTES` | API | 1 KiB – 16 MiB; default 1 MiB. |
| `LOG_LEVEL`, `LOG_JSON` | API | JSON logs by default; `LOG_JSON=false` for readable local output. |
| `NEXT_PUBLIC_API_URL` | Web | Browser-visible API origin. **Inlined at build time**; rebuild the web image after changing. |

Secrets live only in `.env` files, which are git-ignored. `*.example` files contain development-only
placeholders.

## Tests

- `tests/unit/` — pure logic. `test_context.py` and `test_logging.py` need only the standard library;
  `test_config.py` needs pydantic-settings.
- `tests/api/` — in-process ASGI tests with httpx; the database and Redis are replaced by small fakes,
  so these test API behaviour, not database behaviour.
- `tests/integration/` — real asyncpg. The connection-refused test needs no server. The
  PostgreSQL-backed test runs only when `TEST_DATABASE_URL` is set; **a skipped test is not a pass**.
  Concurrency and ledger tests (milestone 3) will require a real PostgreSQL by design.

```bash
cd services/api
uv sync --group dev
TEST_DATABASE_URL=postgresql+asyncpg://aurora:aurora_dev_password@localhost:5432/aurora_test uv run pytest
```

## Smoke test

`infra/scripts/smoke.sh [API_URL] [WEB_URL]` checks liveness, readiness (database `ok`) and the
web index page, and exits non-zero on the first failure.

## Reproducible installs

Run `uv lock` in `services/api` and `npm install` in `apps/web`, then commit `uv.lock` and
`package-lock.json`. Until then the Docker builds resolve compatible ranges at build time and are
not reproducible.
