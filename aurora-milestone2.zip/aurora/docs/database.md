# Database (PostgreSQL 16 is the source of truth)

Migrations: `services/api/alembic/versions/`. Apply with `alembic upgrade head` (the API
container does this on start). Revision `0001` is hand-written; constraint and index names follow
the naming convention in `app/db/base.py`.

## Tables

`users`, `sessions`, `wallets`, `wallet_ledger`, `games`, `game_rounds`, `favorites`,
`achievements`, `user_achievements`, `audit_logs`, `app_settings`. Columns and constraints are in
`app/models/` and `alembic/versions/0001_initial_schema.py`.

## Integrity enforced by the database (not just the app)

- `users.email` stored lower-cased (CHECK); usernames unique case-insensitively
  (`UNIQUE (lower(username))`); role/status limited to known values.
- `wallets.balance_units >= 0`, currency fixed to `DEMO`, one wallet per user.
- `wallet_ledger` is **append-only**: a trigger rejects `UPDATE`, `DELETE` and `TRUNCATE`.
  Corrections are compensating `REVERSAL`/`ADMIN_ADJUSTMENT` rows. Entry type fixes the sign
  (`STAKE_DEBIT < 0`, `PAYOUT_CREDIT/INITIAL_GRANT/DAILY_CLAIM > 0`), `amount <> 0`,
  `balance_after >= 0`, `reference_key` unique.
- A round gets **at most one** `STAKE_DEBIT` and **one** `PAYOUT_CREDIT` (partial unique indexes).
- `game_rounds`: `stake_units > 0`; status in `CREATED | IN_PROGRESS | SETTLED | CANCELLED`;
  `SETTLED` requires `settled_at` and `net = payout - stake`; `UNIQUE (user_id, idempotency_key)`.
- `game_rounds.private_state` holds secret server state (e.g. Mines positions) and must never be
  included in a response schema while a round is unsettled.

## Units

All amounts are integer **units**; 1 DEMO credit = 100 units (`app_settings.economy`).
Seeded economy defaults: initial 1,000,000 units (10,000 credits), stake 100-100,000 units,
max payout 10,000,000 units. These are development defaults, not monetary values.

## Account deletion and retention

Financial and gameplay history must stay consistent, so user rows are **never hard-deleted**
(foreign keys from wallets, rounds and ledger are `ON DELETE RESTRICT`). Deleting an account means:
set `status='deleted'`, `deleted_at`, null `password_hash`, replace `email` with a non-routable
placeholder and `username` with a generated one, revoke all sessions, and delete favorites and
achievement unlocks. Rounds and ledger rows are kept, now unlinked from any identity.
(The deletion endpoint itself arrives with the settings page in a later milestone.)

## Seed data

Migration `0001` inserts reference data only: five games, four achievements, the `economy`
setting. It creates **no** users, balances or statistics.

## Testing against PostgreSQL

`TEST_DATABASE_URL` must point at a dedicated empty database. The test fixture runs
`alembic downgrade base` then `upgrade head`, and test cleanup temporarily disables the ledger
trigger inside the test database only.
