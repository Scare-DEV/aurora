/**
 * Public runtime configuration.
 *
 * NEXT_PUBLIC_* variables are inlined into the browser bundle at build time, so
 * they must be referenced literally (not through a dynamic key) and must never
 * contain secrets.
 */

const rawApiUrl = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

function parseApiBaseUrl(value: string): string {
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new Error(`NEXT_PUBLIC_API_URL is not a valid URL: "${value}"`);
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error("NEXT_PUBLIC_API_URL must use http or https");
  }
  return url.origin;
}

/** Origin of the AURORA API, without a trailing slash. */
export const API_BASE_URL = parseApiBaseUrl(rawApiUrl);

/** Versioned API path prefix; must match the backend's `API_PREFIX`. */
export const API_PREFIX = "/api/v1";
