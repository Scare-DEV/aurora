import type { z } from "zod";

import { API_BASE_URL, API_PREFIX } from "@/lib/config/env";

import {
  errorResponseSchema,
  readinessResponseSchema,
  type FieldError,
  type ReadinessResponse,
} from "./schemas";

/** The request never produced an HTTP response (offline, DNS, CORS, server down). */
export class NetworkError extends Error {
  readonly url: string;

  constructor(url: string, options?: { cause?: unknown }) {
    super("Unable to reach the AURORA API.", options);
    this.name = "NetworkError";
    this.url = url;
  }
}

/** The API answered with an error status. Mirrors the backend error schema. */
export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly requestId: string | undefined;
  readonly fieldErrors: FieldError[] | undefined;

  constructor(init: {
    status: number;
    code: string;
    message: string;
    requestId?: string;
    fieldErrors?: FieldError[];
  }) {
    super(init.message);
    this.name = "ApiError";
    this.status = init.status;
    this.code = init.code;
    this.requestId = init.requestId;
    this.fieldErrors = init.fieldErrors;
  }
}

/** The API answered successfully, but the body did not match the expected schema. */
export class ApiContractError extends Error {
  constructor(
    readonly url: string,
    readonly issues: string,
  ) {
    super("The API returned an unexpected response.");
    this.name = "ApiContractError";
  }
}

export interface ApiFetchOptions extends Omit<RequestInit, "credentials"> {
  /** Non-2xx statuses whose bodies still match the response schema (e.g. 503 readiness). */
  acceptStatuses?: readonly number[];
}

function isAbortError(error: unknown): boolean {
  return error instanceof DOMException && error.name === "AbortError";
}

async function readJson(response: Response): Promise<unknown> {
  try {
    return await response.json();
  } catch {
    return undefined;
  }
}

function toApiError(status: number, body: unknown): ApiError {
  const parsed = errorResponseSchema.safeParse(body);
  if (parsed.success) {
    return new ApiError({
      status,
      code: parsed.data.code,
      message: parsed.data.message,
      requestId: parsed.data.request_id,
      fieldErrors: parsed.data.field_errors,
    });
  }
  return new ApiError({
    status,
    code: "unknown_error",
    message: `The API responded with HTTP ${status}.`,
  });
}

/**
 * Typed fetch against the versioned API. Cookies are sent (`credentials: "include"`)
 * for the cookie-based session introduced in Milestone 2.
 *
 * Never returns fabricated data: transport failures, error statuses and schema
 * mismatches each throw a distinct, catchable error.
 */
export async function apiFetch<S extends z.ZodTypeAny>(
  path: string,
  schema: S,
  options: ApiFetchOptions = {},
): Promise<z.infer<S>> {
  const { acceptStatuses = [], headers, ...init } = options;
  const url = `${API_BASE_URL}${API_PREFIX}${path}`;

  const requestHeaders = new Headers(headers);
  requestHeaders.set("Accept", "application/json");

  let response: Response;
  try {
    response = await fetch(url, { ...init, headers: requestHeaders, credentials: "include" });
  } catch (cause) {
    if (isAbortError(cause)) throw cause;
    throw new NetworkError(url, { cause });
  }

  const body = await readJson(response);
  const parsed = schema.safeParse(body);

  if (response.ok) {
    if (!parsed.success) {
      throw new ApiContractError(url, parsed.error.message);
    }
    return parsed.data;
  }

  // Non-2xx: an explicitly accepted status is data only if its body really matches the
  // schema; otherwise it is an error (e.g. a 503 from a proxy using the error schema).
  if (acceptStatuses.includes(response.status) && parsed.success) {
    return parsed.data;
  }
  throw toApiError(response.status, body);
}

/** GET /api/v1/health/ready. A 503 body is a valid "unavailable" report, not an error. */
export function fetchReadiness(signal?: AbortSignal): Promise<ReadinessResponse> {
  return apiFetch("/health/ready", readinessResponseSchema, {
    signal,
    acceptStatuses: [503],
  });
}
