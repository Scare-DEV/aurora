import { afterEach, describe, expect, it, vi } from "vitest";

import { ApiContractError, ApiError, NetworkError, apiFetch, fetchReadiness } from "./client";
import { readinessResponseSchema } from "./schemas";

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function mockFetch(impl: () => Promise<Response>) {
  const fn = vi.fn(impl);
  vi.stubGlobal("fetch", fn);
  return fn;
}

afterEach(() => {
  vi.unstubAllGlobals();
});

const readyBody = { status: "ok", version: "0.1.0", checks: { database: "ok", redis: "disabled" } };

describe("apiFetch", () => {
  it("returns schema-validated data and sends credentials to the versioned URL", async () => {
    const fetchMock = mockFetch(async () => jsonResponse(readyBody));

    const result = await apiFetch("/health/ready", readinessResponseSchema);

    expect(result).toEqual(readyBody);
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe("http://localhost:8000/api/v1/health/ready");
    expect(init.credentials).toBe("include");
    expect(new Headers(init.headers).get("Accept")).toBe("application/json");
  });

  it("throws NetworkError when no HTTP response is produced", async () => {
    mockFetch(async () => {
      throw new TypeError("Failed to fetch");
    });
    await expect(apiFetch("/health/ready", readinessResponseSchema)).rejects.toBeInstanceOf(
      NetworkError,
    );
  });

  it("rethrows aborts untouched instead of reporting a network failure", async () => {
    mockFetch(async () => {
      throw new DOMException("aborted", "AbortError");
    });
    await expect(apiFetch("/health/ready", readinessResponseSchema)).rejects.toMatchObject({
      name: "AbortError",
    });
  });

  it("maps the backend error schema to ApiError", async () => {
    mockFetch(async () =>
      jsonResponse(
        {
          code: "validation_error",
          message: "The request could not be validated.",
          request_id: "abc12345",
          field_errors: [{ field: "amount", message: "Input should be a valid integer" }],
        },
        422,
      ),
    );

    const error = await apiFetch("/x", readinessResponseSchema).catch((e: unknown) => e);

    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({
      status: 422,
      code: "validation_error",
      requestId: "abc12345",
      fieldErrors: [{ field: "amount", message: "Input should be a valid integer" }],
    });
  });

  it("falls back to a generic ApiError when an error body is not the API schema", async () => {
    mockFetch(async () => new Response("<html>Bad gateway</html>", { status: 502 }));

    const error = await apiFetch("/x", readinessResponseSchema).catch((e: unknown) => e);

    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({ status: 502, code: "unknown_error" });
  });

  it("throws ApiContractError when a 200 body does not match the schema", async () => {
    mockFetch(async () => jsonResponse({ status: "fine" }));
    await expect(apiFetch("/health/ready", readinessResponseSchema)).rejects.toBeInstanceOf(
      ApiContractError,
    );
  });

  it("rejects unexpected enum values instead of rendering them", async () => {
    mockFetch(async () =>
      jsonResponse({ status: "ok", version: "1", checks: { database: "maybe" } }),
    );
    await expect(apiFetch("/health/ready", readinessResponseSchema)).rejects.toBeInstanceOf(
      ApiContractError,
    );
  });
});

describe("fetchReadiness", () => {
  it("treats a 503 readiness report as data, not an error", async () => {
    const body = { status: "unavailable", version: "0.1.0", checks: { database: "error" } };
    mockFetch(async () => jsonResponse(body, 503));
    await expect(fetchReadiness()).resolves.toEqual(body);
  });

  it("throws ApiError for a 503 whose body is an error response, not a readiness report", async () => {
    mockFetch(async () =>
      jsonResponse(
        { code: "http_error", message: "Service Unavailable", request_id: "req-12345" },
        503,
      ),
    );
    const error = await fetchReadiness().catch((e: unknown) => e);
    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({ status: 503, code: "http_error", requestId: "req-12345" });
  });
});
