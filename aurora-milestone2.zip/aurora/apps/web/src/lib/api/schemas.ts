import { z } from "zod";

/**
 * Runtime schemas for API responses. The FastAPI OpenAPI document is the source
 * of truth; these are validated at the boundary so a contract mismatch becomes a
 * visible error instead of silently wrong UI.
 */

export const componentStateSchema = z.enum(["ok", "error", "disabled"]);

export const healthResponseSchema = z.object({
  status: z.literal("ok"),
  service: z.string(),
  version: z.string(),
});

export const readinessResponseSchema = z.object({
  status: z.enum(["ok", "degraded", "unavailable"]),
  version: z.string(),
  checks: z.record(componentStateSchema),
});

export const fieldErrorSchema = z.object({
  field: z.string(),
  message: z.string(),
});

export const errorResponseSchema = z.object({
  code: z.string(),
  message: z.string(),
  request_id: z.string(),
  field_errors: z.array(fieldErrorSchema).optional(),
});

export type ComponentState = z.infer<typeof componentStateSchema>;
export type HealthResponse = z.infer<typeof healthResponseSchema>;
export type ReadinessResponse = z.infer<typeof readinessResponseSchema>;
export type FieldError = z.infer<typeof fieldErrorSchema>;
export type ErrorResponse = z.infer<typeof errorResponseSchema>;
