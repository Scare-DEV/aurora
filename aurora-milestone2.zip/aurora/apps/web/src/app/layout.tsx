import type { Metadata, Viewport } from "next";
import { Inter, Sora } from "next/font/google";
import type { ReactNode } from "react";

import { QueryProvider } from "@/lib/query/query-provider";

import "./globals.css";

const sora = Sora({ subsets: ["latin"], variable: "--font-sora", display: "swap" });
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

export const metadata: Metadata = {
  title: {
    default: "AURORA — virtual-credit gaming simulation",
    template: "%s · AURORA",
  },
  description:
    "AURORA is a virtual-credit gaming simulation. Demo credits have no monetary value; there are no deposits or withdrawals.",
};

export const viewport: Viewport = {
  themeColor: "#080A0F",
  colorScheme: "dark",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${sora.variable} ${inter.variable}`}>
      <body className="bg-background font-sans text-foreground antialiased">
        <QueryProvider>{children}</QueryProvider>
      </body>
    </html>
  );
}
