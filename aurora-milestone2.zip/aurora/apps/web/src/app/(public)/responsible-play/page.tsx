import type { Metadata } from "next";

export const metadata: Metadata = { title: "Responsible play" };

export default function ResponsiblePlayPage() {
  return (
    <article className="mx-auto max-w-3xl">
      <h1 className="font-heading text-3xl font-semibold tracking-tight">Responsible play</h1>
      <p className="mt-4 text-muted">
        AURORA is a simulation. This page explains what that means and how to keep it a healthy
        experience.
      </p>

      <h2 className="mt-8 font-heading text-xl font-semibold">What demo credits are</h2>
      <ul className="mt-3 list-disc space-y-2 pl-5 text-muted">
        <li>Demo credits have no monetary value.</li>
        <li>
          They cannot be bought, deposited, withdrawn, sold, transferred or exchanged for money,
          cryptocurrency or anything else.
        </li>
        <li>AURORA does not accept real-money wagers and has no payment integration.</li>
        <li>
          Games are demonstrations. They are not audited or independently certified gambling
          products, and results say nothing about how a real gambling service would behave.
        </li>
      </ul>

      <h2 className="mt-8 font-heading text-xl font-semibold">Keeping it healthy</h2>
      <ul className="mt-3 list-disc space-y-2 pl-5 text-muted">
        <li>Treat it as entertainment and take regular breaks.</li>
        <li>
          Do not read patterns into short runs of results. Each round is independent, and no
          strategy guarantees an outcome.
        </li>
        <li>
          If you notice that playing, even with demo credits, is getting in the way of sleep, work
          or relationships, step away.
        </li>
      </ul>

      <h2 className="mt-8 font-heading text-xl font-semibold">If real-money gambling is a problem</h2>
      <p className="mt-3 text-muted">
        If gambling with real money is causing you or someone close to you distress, please contact
        a qualified local support service or speak with a health professional.
      </p>

      <p className="mt-8 text-sm text-muted">
        Session-time information, pause and account-disable controls will be added with the account
        features.
      </p>
    </article>
  );
}
