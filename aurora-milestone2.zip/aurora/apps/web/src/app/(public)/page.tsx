import { ClipboardList, Scale, ShieldCheck } from "lucide-react";

import { ApiStatusCard } from "@/components/system/api-status-card";

const PRINCIPLES = [
  {
    icon: ShieldCheck,
    title: "Server-authoritative",
    body: "Outcomes, balances and payouts are calculated and validated on the backend. The browser only displays results; it never decides them.",
  },
  {
    icon: ClipboardList,
    title: "Fully ledgered",
    body: "Every stake and payout is designed to be recorded in an append-only ledger, so any balance can be traced back to the rounds that produced it.",
  },
  {
    icon: Scale,
    title: "Demo credits only",
    body: "Credits have no monetary value. There are no deposits, withdrawals, cash-outs or real-money wagers, and credits cannot be exchanged for anything.",
  },
] as const;

export default function HomePage() {
  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-10">
      <section aria-labelledby="hero-title" className="pt-4">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
          Virtual-credit gaming simulation
        </p>
        <h1
          id="hero-title"
          className="mt-3 max-w-3xl font-heading text-4xl font-semibold leading-tight tracking-tight sm:text-5xl"
        >
          Play with demo credits. Inspect everything.
        </h1>
        <p className="mt-4 max-w-2xl text-base text-muted">
          AURORA is a simulation platform for exploring game mechanics. Nothing here involves real
          money or cryptocurrency, and nothing is presented as an audited or certified gambling
          product.
        </p>
        <p className="mt-4 inline-flex rounded-md border border-border bg-surface px-3 py-2 text-sm text-muted">
          <span className="font-medium text-foreground">Build status:</span>
          &nbsp;foundation. Accounts, the demo wallet and the games are not available yet.
        </p>
      </section>

      <section aria-labelledby="principles-title">
        <h2 id="principles-title" className="font-heading text-xl font-semibold">
          How AURORA is designed
        </h2>
        <ul className="mt-4 grid gap-4 md:grid-cols-3">
          {PRINCIPLES.map(({ icon: Icon, title, body }) => (
            <li key={title} className="rounded-lg border border-border bg-surface p-5">
              <Icon className="size-5 text-accent" aria-hidden="true" />
              <h3 className="mt-3 font-heading text-base font-semibold">{title}</h3>
              <p className="mt-2 text-sm text-muted">{body}</p>
            </li>
          ))}
        </ul>
      </section>

      <ApiStatusCard />
    </div>
  );
}
