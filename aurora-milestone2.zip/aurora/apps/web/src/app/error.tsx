"use client";

import { Button } from "@/components/ui/button";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="mx-auto flex min-h-dvh max-w-xl flex-col items-start justify-center gap-4 px-6">
      <h1 className="font-heading text-3xl font-semibold">Something went wrong</h1>
      <p className="text-muted">
        The page failed to load. No game result or balance was changed by this error.
      </p>
      {error.digest && (
        <p className="text-sm text-muted">
          Reference: <span className="tabular-nums">{error.digest}</span>
        </p>
      )}
      <Button variant="primary" onClick={reset}>
        Try again
      </Button>
    </main>
  );
}
