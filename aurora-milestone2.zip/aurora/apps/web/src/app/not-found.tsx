import Link from "next/link";

import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils/cn";

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-dvh max-w-xl flex-col items-start justify-center gap-4 px-6">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">404</p>
      <h1 className="font-heading text-3xl font-semibold">Page not found</h1>
      <p className="text-muted">That page does not exist, or it has not been built yet.</p>
      <Link href="/" className={cn(buttonVariants({ variant: "primary" }))}>
        Back to home
      </Link>
    </main>
  );
}
