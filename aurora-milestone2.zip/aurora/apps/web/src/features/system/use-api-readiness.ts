"use client";

import { useQuery } from "@tanstack/react-query";

import { fetchReadiness } from "@/lib/api/client";

export const READINESS_QUERY_KEY = ["api", "readiness"] as const;

/** Polls the API readiness probe. Retry policy comes from the QueryClient defaults. */
export function useApiReadiness() {
  return useQuery({
    queryKey: READINESS_QUERY_KEY,
    queryFn: ({ signal }) => fetchReadiness(signal),
    refetchInterval: 30_000,
  });
}
