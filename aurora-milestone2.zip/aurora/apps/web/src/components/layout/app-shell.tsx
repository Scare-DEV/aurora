"use client";

import { useState, type ReactNode } from "react";

import { Footer } from "./footer";
import { Header } from "./header";
import { Sidebar } from "./sidebar";

const SIDEBAR_ID = "primary-sidebar";

export function AppShell({ children }: { children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="flex min-h-dvh flex-col">
      <a href="#main" className="skip-link">
        Skip to main content
      </a>
      <Header
        sidebarId={SIDEBAR_ID}
        sidebarCollapsed={collapsed}
        onToggleSidebar={() => setCollapsed((value) => !value)}
      />
      <div className="flex flex-1">
        <Sidebar id={SIDEBAR_ID} collapsed={collapsed} />
        <div className="flex min-w-0 flex-1 flex-col">
          <main id="main" tabIndex={-1} className="flex-1 px-6 py-8 focus:outline-none lg:px-10">
            {children}
          </main>
          <Footer />
        </div>
      </div>
    </div>
  );
}
