import { PanelLeftClose, PanelLeftOpen } from "lucide-react";
import Link from "next/link";

import { Button } from "@/components/ui/button";

import { AuroraWordmark } from "./aurora-wordmark";

interface HeaderProps {
  sidebarId: string;
  sidebarCollapsed: boolean;
  onToggleSidebar: () => void;
}

export const DEMO_NOTICE_TEXT = "DEMO CREDITS — NO MONETARY VALUE";

export function Header({ sidebarId, sidebarCollapsed, onToggleSidebar }: HeaderProps) {
  const ToggleIcon = sidebarCollapsed ? PanelLeftOpen : PanelLeftClose;

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur">
      <div
        role="note"
        className="flex h-7 items-center justify-center bg-accent-secondary/15 px-4 text-[11px] font-semibold tracking-[0.14em] text-accent-secondary"
      >
        {DEMO_NOTICE_TEXT}
      </div>
      <div className="flex h-14 items-center gap-3 px-4 lg:px-6">
        {/* The sidebar only exists at lg+, so its toggle is hidden below that width. */}
        <Button
          variant="ghost"
          size="icon"
          className="hidden lg:inline-flex"
          aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          aria-expanded={!sidebarCollapsed}
          aria-controls={sidebarId}
          onClick={onToggleSidebar}
        >
          <ToggleIcon className="size-4" aria-hidden="true" />
        </Button>

        <Link href="/" aria-label="AURORA home" className="rounded-md">
          <AuroraWordmark />
        </Link>

        <nav aria-label="Secondary" className="ml-auto flex items-center gap-1">
          <Link
            href="/responsible-play"
            className="rounded-md px-3 py-2 text-sm text-muted transition-colors hover:text-foreground"
          >
            Responsible play
          </Link>
        </nav>
      </div>
    </header>
  );
}
