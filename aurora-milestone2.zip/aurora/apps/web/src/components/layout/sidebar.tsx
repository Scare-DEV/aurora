"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { NAV_ITEMS } from "@/components/navigation/nav-config";
import { cn } from "@/lib/utils/cn";

interface SidebarProps {
  id: string;
  collapsed: boolean;
}

const rowClasses = "flex h-10 items-center gap-3 rounded-md px-3 text-sm";

export function Sidebar({ id, collapsed }: SidebarProps) {
  const pathname = usePathname();

  return (
    <nav
      id={id}
      aria-label="Primary"
      data-collapsed={collapsed}
      className={cn(
        "sticky top-[var(--header-height)] hidden h-[calc(100dvh-var(--header-height))] shrink-0 self-start overflow-y-auto border-r border-border bg-surface p-3 transition-[width] duration-200 lg:block",
        collapsed ? "w-[var(--sidebar-width-collapsed)]" : "w-[var(--sidebar-width)]",
      )}
    >
      <ul className="flex flex-col gap-1">
        {NAV_ITEMS.map(({ label, href, icon: Icon, available }) => {
          const labelClass = collapsed ? "sr-only" : "truncate";

          if (!available) {
            return (
              <li key={href}>
                <span className={cn(rowClasses, "cursor-default text-muted/60")}>
                  <Icon className="size-4 shrink-0" aria-hidden="true" />
                  <span className={labelClass}>{label}</span>
                  <span className="sr-only"> (not available yet)</span>
                  {!collapsed && (
                    <span
                      aria-hidden="true"
                      className="ml-auto rounded-sm border border-border px-1.5 py-0.5 text-[10px] uppercase tracking-wide"
                    >
                      Soon
                    </span>
                  )}
                </span>
              </li>
            );
          }

          const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
          return (
            <li key={href}>
              <Link
                href={href}
                title={collapsed ? label : undefined}
                aria-current={active ? "page" : undefined}
                className={cn(
                  rowClasses,
                  "transition-colors",
                  active
                    ? "bg-surface-elevated text-foreground"
                    : "text-muted hover:bg-surface-elevated hover:text-foreground",
                )}
              >
                <Icon
                  className={cn("size-4 shrink-0", active && "text-accent")}
                  aria-hidden="true"
                />
                <span className={labelClass}>{label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
