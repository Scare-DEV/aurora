import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t border-border px-6 py-6 text-sm text-muted lg:px-10">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <p>
          AURORA is a simulation. Demo credits have no monetary value and cannot be deposited,
          withdrawn, sold or exchanged.
        </p>
        <Link href="/responsible-play" className="rounded-sm underline underline-offset-4 hover:text-foreground">
          Responsible play
        </Link>
      </div>
    </footer>
  );
}
