import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

import { AppShell } from "./app-shell";
import { DEMO_NOTICE_TEXT } from "./header";

vi.mock("next/navigation", () => ({ usePathname: () => "/" }));

function renderShell() {
  return render(
    <AppShell>
      <p>page content</p>
    </AppShell>,
  );
}

describe("AppShell", () => {
  it("always shows the demo-credits notice", () => {
    renderShell();
    expect(screen.getByRole("note")).toHaveTextContent(DEMO_NOTICE_TEXT);
  });

  it("provides a skip link and a focusable main landmark", () => {
    renderShell();
    expect(screen.getByRole("link", { name: /skip to main content/i })).toHaveAttribute(
      "href",
      "#main",
    );
    expect(screen.getByRole("main")).toHaveAttribute("id", "main");
    expect(screen.getByText("page content")).toBeInTheDocument();
  });

  it("marks the current page and exposes only real pages as links", () => {
    renderShell();
    const nav = screen.getByRole("navigation", { name: "Primary" });

    const home = within(nav).getByRole("link", { name: "Home" });
    expect(home).toHaveAttribute("aria-current", "page");

    // Pages that do not exist yet must not be clickable controls.
    expect(within(nav).queryByRole("link", { name: /dice/i })).not.toBeInTheDocument();
    expect(within(nav).queryByRole("button")).not.toBeInTheDocument();
    expect(within(nav).getByText(/dice/i)).toBeInTheDocument();
    expect(within(nav).getAllByText(/not available yet/i).length).toBeGreaterThan(0);
  });

  it("collapses and expands the sidebar with correct ARIA state", async () => {
    renderShell();
    const nav = screen.getByRole("navigation", { name: "Primary" });
    const toggle = screen.getByRole("button", { name: /collapse sidebar/i });

    expect(toggle).toHaveAttribute("aria-expanded", "true");
    expect(toggle).toHaveAttribute("aria-controls", nav.id);
    expect(nav).toHaveAttribute("data-collapsed", "false");

    await userEvent.click(toggle);

    const expand = screen.getByRole("button", { name: /expand sidebar/i });
    expect(expand).toHaveAttribute("aria-expanded", "false");
    expect(nav).toHaveAttribute("data-collapsed", "true");
    // Labels remain available to assistive technology when visually collapsed.
    expect(within(nav).getByRole("link", { name: "Home" })).toBeInTheDocument();
  });

  it("is operable by keyboard", async () => {
    renderShell();
    const user = userEvent.setup();
    await user.tab(); // skip link first
    expect(screen.getByRole("link", { name: /skip to main content/i })).toHaveFocus();

    const toggle = screen.getByRole("button", { name: /collapse sidebar/i });
    toggle.focus();
    await user.keyboard("{Enter}");
    expect(screen.getByRole("button", { name: /expand sidebar/i })).toBeInTheDocument();
  });
});
