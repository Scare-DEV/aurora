import { cn } from "@/lib/utils/cn";

/** Original AURORA mark: a triangular peak crossed by an aurora arc. */
export function AuroraMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" fill="none" aria-hidden="true" className={cn("size-7", className)}>
      <path
        d="M16 4 L28 27 H4 Z"
        className="stroke-accent"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <path
        d="M9.5 21 Q16 13.5 22.5 21"
        className="stroke-accent-secondary"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function AuroraWordmark({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <AuroraMark />
      <span className="font-heading text-lg font-semibold tracking-[0.22em] text-foreground">
        AURORA
      </span>
    </span>
  );
}
