import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";

import { ApiStatusCard } from "./api-status-card";

function renderCard() {
  const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  return render(
    <QueryClientProvider client={client}>
      <ApiStatusCard />
    </QueryClientProvider>,
  );
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("ApiStatusCard", () => {
  it("shows a loading message, then the reported component states", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () =>
        jsonResponse({
          status: "ok",
          version: "0.1.0",
          checks: { database: "ok", redis: "disabled" },
        }),
      ),
    );

    renderCard();
    expect(screen.getByText(/checking the api/i)).toBeInTheDocument();

    expect(await screen.findByText("All systems operational")).toBeInTheDocument();
    expect(screen.getByText("Database (PostgreSQL)")).toBeInTheDocument();
    expect(screen.getByText("Operational")).toBeInTheDocument();
    expect(screen.getByText("Not configured")).toBeInTheDocument();
  });

  it("reports an unavailable database from a 503 readiness response", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () =>
        jsonResponse(
          { status: "unavailable", version: "0.1.0", checks: { database: "error", redis: "ok" } },
          503,
        ),
      ),
    );

    renderCard();

    expect(await screen.findByText("API unavailable")).toBeInTheDocument();
    expect(screen.getByText("Unavailable")).toBeInTheDocument();
  });

  it("shows an honest error, not fabricated status, when the API cannot be reached", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => {
        throw new TypeError("Failed to fetch");
      }),
    );

    renderCard();

    expect(await screen.findByText("Cannot reach the API")).toBeInTheDocument();
    expect(screen.queryByText("All systems operational")).not.toBeInTheDocument();
    expect(screen.queryByText("Operational")).not.toBeInTheDocument();
  });

  it("flags a failed re-check instead of silently showing stale success", async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValueOnce(
        jsonResponse({ status: "ok", version: "0.1.0", checks: { database: "ok" } }),
      )
      .mockRejectedValueOnce(new TypeError("Failed to fetch"));
    vi.stubGlobal("fetch", fetchMock);

    renderCard();
    await screen.findByText("All systems operational");

    await userEvent.click(screen.getByRole("button", { name: /re-check platform status/i }));

    expect(await screen.findByText(/latest re-check failed/i)).toBeInTheDocument();
  });
});
