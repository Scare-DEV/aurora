"use client";

import { CheckCircle2, MinusCircle, RefreshCw, XCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useApiReadiness } from "@/features/system/use-api-readiness";
import { ApiContractError, ApiError, NetworkError } from "@/lib/api/client";
import type { ComponentState, ReadinessResponse } from "@/lib/api/schemas";
import { API_BASE_URL } from "@/lib/config/env";

const COMPONENT_LABELS: Record<string, string> = {
  database: "Database (PostgreSQL)",
  redis: "Cache (Redis)",
};

const STATE_PRESENTATION: Record<
  ComponentState,
  { label: string; Icon: typeof CheckCircle2; className: string }
> = {
  ok: { label: "Operational", Icon: CheckCircle2, className: "text-success" },
  error: { label: "Unavailable", Icon: XCircle, className: "text-danger" },
  disabled: { label: "Not configured", Icon: MinusCircle, className: "text-muted" },
};

const OVERALL_LABELS: Record<ReadinessResponse["status"], string> = {
  ok: "All systems operational",
  degraded: "Running with reduced capability",
  unavailable: "API unavailable",
};

function describeError(error: unknown): { title: string; detail: string } {
  if (error instanceof NetworkError) {
    return {
      title: "Cannot reach the API",
      detail: `No response from ${API_BASE_URL}. Check that the backend is running and that CORS allows this origin.`,
    };
  }
  if (error instanceof ApiError) {
    return {
      title: "The API returned an error",
      detail: `${error.message} (code: ${error.code}${error.requestId ? `, request ID: ${error.requestId}` : ""})`,
    };
  }
  if (error instanceof ApiContractError) {
    return {
      title: "Unexpected API response",
      detail: "The API answered, but not in the expected format. The frontend and backend may be out of sync.",
    };
  }
  return { title: "Status check failed", detail: "An unknown error occurred." };
}

export function ApiStatusCard() {
  const { data, error, isPending, isFetching, refetch } = useApiReadiness();

  return (
    <section
      aria-labelledby="platform-status-title"
      className="rounded-lg border border-border bg-surface p-5 shadow-[var(--shadow-elevated)]"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 id="platform-status-title" className="font-heading text-base font-semibold">
            Platform status
          </h2>
          <p className="mt-1 text-sm text-muted">Live readiness check against the AURORA API.</p>
        </div>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => void refetch()}
          disabled={isFetching}
          aria-label="Re-check platform status"
        >
          <RefreshCw className={`size-3.5 ${isFetching ? "animate-spin" : ""}`} aria-hidden="true" />
          Re-check
        </Button>
      </div>

      <div role="status" aria-live="polite" className="mt-4">
        {isPending && <p className="text-sm text-muted">Checking the API…</p>}

        {!isPending && error && !data && (
          <div>
            <p className="flex items-center gap-2 text-sm font-medium text-danger">
              <XCircle className="size-4" aria-hidden="true" />
              {describeError(error).title}
            </p>
            <p className="mt-1 text-sm text-muted">{describeError(error).detail}</p>
          </div>
        )}

        {data && (
          <div>
            {error && (
              <p className="mb-2 text-sm text-danger">
                The latest re-check failed ({describeError(error).title.toLowerCase()}). Showing the
                previous result, which may be out of date.
              </p>
            )}
            <p className="text-sm font-medium">
              {OVERALL_LABELS[data.status]}
              <span className="ml-2 font-normal text-muted tabular-nums">API v{data.version}</span>
            </p>
            <ul className="mt-3 divide-y divide-border rounded-md border border-border">
              {Object.entries(data.checks).map(([name, state]) => {
                const { label, Icon, className } = STATE_PRESENTATION[state];
                return (
                  <li key={name} className="flex items-center justify-between px-3 py-2 text-sm">
                    <span>{COMPONENT_LABELS[name] ?? name}</span>
                    <span className={`flex items-center gap-1.5 ${className}`}>
                      <Icon className="size-4" aria-hidden="true" />
                      {label}
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </div>
    </section>
  );
}
