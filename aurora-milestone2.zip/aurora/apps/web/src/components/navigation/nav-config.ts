import {
  Award,
  CircleDot,
  Coins,
  Dices,
  Gamepad2,
  Heart,
  History,
  Home,
  Rocket,
  Bomb,
  Trophy,
  type LucideIcon,
} from "lucide-react";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
  /**
   * Items whose page does not exist yet render as plain, non-interactive text
   * (never as a link or button that does nothing). Flip to `true` when the page ships.
   */
  available: boolean;
}

export const NAV_ITEMS: readonly NavItem[] = [
  { label: "Home", href: "/", icon: Home, available: true },
  { label: "All Games", href: "/games", icon: Gamepad2, available: false },
  { label: "Dice", href: "/games/dice", icon: Dices, available: false },
  { label: "Mines", href: "/games/mines", icon: Bomb, available: false },
  { label: "Plinko", href: "/games/plinko", icon: CircleDot, available: false },
  { label: "Limbo", href: "/games/limbo", icon: Rocket, available: false },
  { label: "Coin Flip", href: "/games/coin-flip", icon: Coins, available: false },
  { label: "Favorites", href: "/favorites", icon: Heart, available: false },
  { label: "Game History", href: "/history", icon: History, available: false },
  { label: "Achievements", href: "/achievements", icon: Award, available: false },
  { label: "Leaderboard", href: "/leaderboard", icon: Trophy, available: false },
];
