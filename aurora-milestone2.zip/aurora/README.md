# AURORA

A virtual-credit gaming **simulation** platform: Next.js frontend, FastAPI backend, PostgreSQL.

> **DEMO CREDITS — NO MONETARY VALUE.** AURORA has no deposits, withdrawals, cash-outs, payment
> processors, cryptocurrency wallets or real-money wagers, and none will be added. Demo credits
> cannot be transferred, sold, redeemed or exchanged. The games are demonstrations, not audited or
> independently certified gambling products.

## Status: Milestone 1 of 8 (foundation)

| Milestone | Scope | State |
| --- | --- | --- |
| **1** | Repo, Docker Compose, Next.js shell, FastAPI health endpoints, PostgreSQL connection, config, design tokens | **Source written; see [Verification](#verification-status)** |
| 2 | Models, Alembic migrations, authentication, sessions, security tests | **Source written; DB-level SQL verified on PostgreSQL 16, app code not run** (see [M2 verification](#milestone-2-verification)) |
| 3 | Wallet, immutable ledger, idempotency, concurrency tests | Not started |
| 4 | Game engine abstraction, Dice, Coin Flip | Not started |
| 5 | Mines, Plinko, Limbo | Not started |
| 6 | History, favorites, statistics, leaderboard | Not started |
| 7 | Admin dashboard, audit logging, configurable limits | Not started |
| 8 | Accessibility, e2e tests, security review, deployment docs | Not started |

Milestone 2 adds registration/login/logout/profile endpoints (server-side sessions, CSRF, rate limits) and the full schema, but the web app has no login UI yet. There is no wallet service or games yet. The web app currently shows the application shell,
the demo-credits notice, a Responsible Play page, and a live API readiness card.

## Prerequisites

- Docker with Compose v2 (for the full stack), **or** Python 3.12+, [uv](https://docs.astral.sh/uv/),
  Node.js 20.9+ (22 recommended), a local PostgreSQL 16, and optionally Redis.

## Quick start (Docker Compose)

```bash
cp .env.example .env            # review values; never commit .env
docker compose up --build --wait
./infra/scripts/smoke.sh        # checks API liveness/readiness and the web app
```

- Web: http://localhost:3000
- API docs: http://localhost:8000/docs
- All ports bind to `127.0.0.1` only.

### One-time: generate lockfiles

Dependencies are declared as **compatible ranges, not verified pins**. On a networked machine,
resolve and commit lockfiles so builds are reproducible (CI's `npm ci` requires the npm one):

```bash
(cd services/api && uv lock)
(cd apps/web && npm install)    # creates package-lock.json
```

Then switch `services/api/Dockerfile` to `uv sync --frozen --no-dev`.

## Local development without Docker

```bash
# API
cd services/api
cp .env.example .env
uv sync --group dev
uv run uvicorn app.main:create_app --factory --reload   # http://localhost:8000

# Web (second terminal)
cd apps/web
cp .env.example .env.local
npm install
npm run dev                                             # http://localhost:3000
```

## Checks

```bash
# API (services/api)
uv run ruff check . && uv run ruff format --check .
uv run mypy app
uv run pytest                                  # set TEST_DATABASE_URL to include the DB test

# Web (apps/web)
npm run lint && npm run typecheck && npm test && npm run build
```

## Repository layout

```
apps/web/            Next.js App Router frontend
services/api/        FastAPI backend (app/core, app/db, app/api, tests/)
packages/            shared-contracts (reserved)
infra/scripts/       smoke.sh
docs/                architecture.md, development.md
docker-compose.yml   postgres, redis, api, web
```

## Verification status

This table records what was **actually executed** when Milestone 1 was written, in a sandbox
whose network policy blocked npm and PyPI and which had no Docker daemon. Anything not marked
as run has **not** been verified.

| Check | Result |
| --- | --- |
| `ruff check` / `ruff format --check` (API) | Ran, clean |
| Byte-compile all API Python | Ran, OK |
| `pytest` on stdlib-only tests (`tests/unit/test_context.py`, `test_logging.py`) | Ran: **20 passed** |
| `mypy --strict` on `context.py`, `logging.py` | Ran, clean |
| `docker compose config` (static validation, incl. fail-fast on missing secrets) | Ran, OK |
| `bash -n infra/scripts/smoke.sh` | Ran, OK |
| Syntax parse of all 27 web TS/TSX files | Ran, 0 syntax errors (re-run 2026-10-11, same result) |
| API `pytest`: config, health, errors/middleware, DB tests | **Not run** (needs FastAPI, pydantic-settings, httpx, asyncpg) |
| `mypy app` (full) | **Not run** (needs dependencies) |
| Web `tsc`, `eslint`, `vitest`, `next build` | **Not run** (needs npm packages). A `tsc` attempt produced 226 errors, all from missing packages/types, so it proves nothing |
| `docker compose up`, image builds, `smoke.sh` against a live stack | **Not run** (no Docker daemon) |
| Lockfiles | **Not generated** |

**Re-verification, 2026-10-11.** A second session re-ran every check marked "Ran" above and got the
same results (ruff clean, 20 stdlib tests passed, `docker compose config` OK, `smoke.sh` syntax OK,
0 web syntax errors). That environment also had no access to npm or PyPI (DNS resolution failed;
the local uv cache lacks FastAPI/SQLAlchemy/Next) and no Docker daemon, so the "Not run" rows are
unchanged. The API source was additionally reviewed by reading it; that is not a substitute for
running it.

### Required before Milestone 1 can be called done

On a machine with network access and Docker, in this order, and fix whatever fails:

```bash
(cd services/api && uv lock && uv sync --group dev && uv run ruff check . && uv run mypy app \
  && TEST_DATABASE_URL=postgresql+asyncpg://aurora:aurora_dev_password@localhost:5432/aurora uv run pytest)
(cd apps/web && npm install && npm run lint && npm run typecheck && npm test && npm run build)
cp .env.example .env && docker compose up --build --wait && ./infra/scripts/smoke.sh
```

Then commit `uv.lock` and `package-lock.json` (CI's web job needs the latter).

## Milestone 2 verification

Executed in this sandbox (still no npm/PyPI access, so FastAPI/SQLAlchemy/argon2/Alembic are not installed):

| Check | Result |
| --- | --- |
| `ruff check` + `ruff format --check` on all API code and tests | Ran, clean |
| Byte-compile `app`, `alembic`, `tests` | Ran, OK |
| `tests/unit/test_rate_limit.py` + the earlier stdlib tests | Ran: **25 passed**, using a small stand-in async test hook because `pytest-asyncio` is not installed here |
| Migration SQL (CHECK constraints and every `op.execute` statement extracted from `0001`) run on a real PostgreSQL 16: email/role/status/username checks, nonnegative balance, DEMO-only currency, stake > 0, settled-round consistency, ledger sign rules, duplicate `reference_key`, `UPDATE`/`DELETE`/`TRUNCATE` on the ledger rejected by the trigger | Ran, every violation was rejected and every valid row accepted |
| Partial unique indexes (one stake debit and one payout per round), with the same definitions as the migration | Ran, duplicates rejected |
| Test-cleanup pattern (`DISABLE TRIGGER USER`, delete, re-enable) | Ran, trigger active again afterwards |
| `alembic upgrade head` / `downgrade base` through the real CLI | **Not run** (Alembic not installed). The DDL in `0001` was hand-written; the table/column layout around the SQL above was mirrored by hand, not generated from the migration |
| `test_security.py`, `test_auth_schemas.py`, `test_round_state_machine.py`, `tests/security/*`, `tests/integration/*` | **Written, not run** (need argon2-cffi, email-validator, SQLAlchemy, FastAPI, httpx, asyncpg) |
| Any auth endpoint against a live server | **Not run** |

Expect first-run failures in the "written, not run" rows; they have never executed.

## Known limitations (Milestone 1)

- Stack items from the spec not yet added because nothing uses them (and they could not be
  resolved/verified offline): Framer Motion, React Hook Form + `@hookform/resolvers`, Radix
  primitives for shadcn/ui components, Playwright. They arrive with the milestones that need them
  (forms in M2, game UI in M4+, e2e in M8).
- Alembic is declared as a dependency, but there are no migrations until Milestone 2.

- Dependency versions are unverified ranges until lockfiles exist.
- No Content-Security-Policy on the web app yet (needs nonces; scheduled for milestone 8).
- Fonts (Sora, Inter) are fetched from Google Fonts by `next/font` at **build** time, so the web
  build needs outbound network access.
- Mobile navigation is not built yet (the sidebar appears at `lg` and up); responsive polish is
  milestone 8.

See [docs/architecture.md](docs/architecture.md) and [docs/development.md](docs/development.md).
